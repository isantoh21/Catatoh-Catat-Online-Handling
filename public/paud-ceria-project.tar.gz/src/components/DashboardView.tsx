import React, { useState, useMemo } from 'react';
import { Layout, Code2, Copy, CheckCircle2, Search, Calendar, DollarSign, X, MessageCircle, RefreshCw, CheckSquare, Square, Save } from 'lucide-react';

const nextJsCode = `'use client';

import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabaseClient';
import { Search, Calendar, DollarSign, X, MessageCircle, RefreshCw, CheckSquare, Square, Save } from 'lucide-react';

const BULAN_OPTIONS = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];
const YEAR_OPTIONS = Array.from({ length: 2045 - 2023 + 1 }, (_, i) => 2023 + i);

export default function DashboardPage() {
  const [students, setStudents] = useState<any[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Filter state
  const currentDate = new Date();
  const [selectedBulan, setSelectedBulan] = useState(BULAN_OPTIONS[currentDate.getMonth()]);
  const [selectedTahun, setSelectedTahun] = useState(currentDate.getFullYear().toString());
  const [searchQuery, setSearchQuery] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isReminderModalOpen, setIsReminderModalOpen] = useState(false);
  const [reminderBulan, setReminderBulan] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedModalBulan, setSelectedModalBulan] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [nominal, setNominal] = useState('100000');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  useEffect(() => {
    fetchData();

    const studentsChannel = supabase
      .channel('realtime-students')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'students' }, (payload) => {
        console.log('Real-time update on students:', payload);
        fetchData();
      })
      .subscribe();
      
    const paymentsChannel = supabase
      .channel('realtime-payments')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'payments' }, (payload) => {
        console.log('Real-time update on payments:', payload);
        fetchData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(studentsChannel);
      supabase.removeChannel(paymentsChannel);
    };
  }, [selectedBulan, selectedTahun]);

  const fetchData = async () => {
    setLoading(true);
    
    // Fetch active students
    const { data: studentsData } = await supabase
      .from('students')
      .select('*')
      .eq('status_aktif', true)
      .order('nama_lengkap', { ascending: true });
      
    if (studentsData) setStudents(studentsData);

    // Fetch payments for selected year
    let paymentsQuery = supabase
      .from('payments')
      .select('*')
      .eq('tahun', parseInt(selectedTahun));
      
    if (selectedBulan !== 'Semua Bulan') {
      paymentsQuery = paymentsQuery.eq('bulan', selectedBulan);
    }
    const { data: paymentsData } = await paymentsQuery;
      
    if (paymentsData) setPayments(paymentsData);
    
    setLoading(false);
  };

  const handleOpenModal = (student: any, explicitBulan?: string) => {
    setSelectedModalBulan(explicitBulan || selectedBulan);
    setSelectedStudent(student);
    setNominal(student.nominal_spp?.toString() || '100000');
    setIsModalOpen(true);
  };

  const handleTandaiLunas = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent) return;
    
    setIsSubmitting(true);
    const today = new Date().toISOString().split('T')[0];
    
    const { error } = await supabase.from('payments').insert([
      { 
        student_id: selectedStudent.id,
        bulan: selectedModalBulan || selectedBulan,
        tahun: parseInt(selectedTahun),
        nominal_dibayar: parseFloat(nominal),
        tanggal_bayar: today,
        status_pembayaran: 'Lunas'
      }
    ]);

    setIsSubmitting(false);
    
    if (!error) {
      setIsModalOpen(false);
      setSelectedStudent(null);
      fetchData(); // Refresh data
    } else {
      alert('Gagal menyimpan pembayaran: ' + error.message);
    }
  };

  const handleBatalkanLunas = async (studentId: string, explicitBulan?: string) => {
    if (!window.confirm('Yakin ingin membatalkan status lunas ini?')) return;
    const { error } = await supabase
      .from('payments')
      .delete()
      .eq('student_id', studentId)
      .eq('bulan', explicitBulan || selectedBulan)
      .eq('tahun', parseInt(selectedTahun));
      
    if (!error) fetchData();
    else alert('Gagal membatalkan lunas: ' + error.message);
  };

  const handleBulkLunas = async () => {
    if (selectedIds.length === 0) return;
    if (!window.confirm(\`Yakin ingin menandai \${selectedIds.length} siswa terpilih sebagai Lunas?\`)) return;
    
    setIsSubmitting(true);
    const today = new Date().toISOString().split('T')[0];
    const records = selectedIds.map(id => {
      const student = students.find(s => s.id === id);
      return {
        student_id: id,
        bulan: selectedModalBulan || selectedBulan,
        tahun: parseInt(selectedTahun),
        nominal_dibayar: student?.nominal_spp || 100000,
        tanggal_bayar: today,
        status_pembayaran: 'Lunas'
      };
    });

    const { error } = await supabase.from('payments').insert(records);
    setIsSubmitting(false);
    
    if (!error) {
      setSelectedIds([]);
      fetchData();
    } else {
      alert('Gagal menyimpan pembayaran: ' + error.message);
    }
  };

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedIds(filteredStudents.map(s => s.id));
    } else {
      setSelectedIds([]);
    }
  };

  const handleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]);
  };

  const filteredStudents = students.filter(s => 
    s.nama_lengkap.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const belumLunasStudents = filteredStudents.filter(s => 
    !payments.some(p => p.student_id === s.id && p.bulan === (isReminderModalOpen ? reminderBulan : selectedBulan))
  );

  const handleKirimWA = (student: any) => {
    const message = \`Halo Ayah/Bunda \${student.nama_lengkap}, mohon maaf mengingatkan untuk pembayaran SPP PAUD bulan \${reminderBulan || selectedBulan} \${selectedTahun} belum tercatat. Terima kasih.\`;
    const url = \`https://wa.me/\${student.nomor_whatsapp}?text=\${encodeURIComponent(message)}\`;
    window.open(url, '_blank');
  };

  return (
    <div className="p-6 md:p-8 max-w-6xl mx-auto space-y-6 font-sans">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Pembayaran SPP</h1>
          <p className="text-sm text-slate-500">Monitor dan catat pembayaran bulanan siswa</p>
        </div>
        <button 
          onClick={() => { setReminderBulan(selectedBulan === 'Semua Bulan' ? 'Januari' : selectedBulan); setIsReminderModalOpen(true); }}
          className="px-4 py-2 text-sm font-bold rounded-xl flex items-center gap-2 transition-colors shadow-sm bg-emerald-600 text-white hover:bg-emerald-700"
        >
          <MessageCircle className="w-5 h-5" />
          Kirim Reminder ke Semua yang Belum Lunas
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input 
            type="text" 
            placeholder="Cari nama siswa..." 
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" 
          />
        </div>
        <div className="flex gap-4">
          <div className="flex gap-2 items-center">
            {selectedIds.length > 0 && (
              <button 
                onClick={handleBulkLunas}
                disabled={isSubmitting}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold flex items-center gap-2 transition-colors shadow-sm disabled:opacity-50"
              >
                <CheckSquare className="w-4 h-4" /> Tandai Lunas ({selectedIds.length})
              </button>
            )}
            <button 
              onClick={fetchData}
              disabled={loading}
              className="px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-sm font-bold items-center justify-center gap-2 transition-colors shadow-sm hidden sm:flex disabled:opacity-50"
            >
              <RefreshCw className={\`w-4 h-4 \${loading ? 'animate-spin' : ''}\`} /> Sync
            </button>
          </div>
          <div className="relative w-40">
            <select 
              value={selectedBulan}
              onChange={e => setSelectedBulan(e.target.value)}
              className="w-full pl-4 pr-8 py-2.5 text-sm border border-slate-200 rounded-lg appearance-none focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium text-slate-700 bg-slate-50"
            >
              <option value="Semua Bulan">Semua Bulan</option>
              {BULAN_OPTIONS.map(b => <option key={b} value={b}>{b}</option>)}
            </select>
          </div>
          <div className="relative w-32">
            <select 
              value={selectedTahun}
              onChange={e => setSelectedTahun(e.target.value)}
              className="w-full pl-4 pr-8 py-2.5 text-sm border border-slate-200 rounded-lg appearance-none focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium text-slate-700 bg-slate-50"
            >
              {YEAR_OPTIONS.map(y => (
                <option key={y} value={y.toString()}>{y}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

{/* Matrix / Regular Table Switch */}
      {selectedBulan === 'Semua Bulan' ? (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col overflow-hidden relative">
          <div className="overflow-x-auto">
            <table className="w-full text-left min-w-[800px]">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest sticky left-0 bg-slate-50 z-10 border-r border-slate-100 shadow-[1px_0_0_0_#f1f5f9]">Nama Siswa</th>
                  {BULAN_OPTIONS.map(b => (
                    <th key={b} className="px-3 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center min-w-[80px]">{b.slice(0, 3)}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredStudents.length === 0 ? (
                  <tr><td colSpan={13} className="px-6 py-8 text-center text-sm text-slate-500">Tidak ada data siswa.</td></tr>
                ) : (
                  filteredStudents.map(student => (
                    <tr key={student.id} className="hover:bg-slate-50/50 transition-colors group/row">
                      <td className="px-6 py-3 sticky left-0 bg-white group-hover/row:bg-slate-50 z-10 border-r border-slate-100 shadow-[1px_0_0_0_#f1f5f9] transition-colors">
                        <p className="text-sm font-bold text-slate-800 truncate max-w-[150px]" title={student.nama_lengkap}>{student.nama_lengkap}</p>
                      </td>
                      {BULAN_OPTIONS.map(b => {
                        const payment = payments.find(p => p.student_id === student.id && p.bulan === b);
                        return (
                          <td key={b} className="px-2 py-2 text-center">
                            {payment ? (
                              <button 
                                onClick={() => handleBatalkanLunas(student.id, b)}
                                className="w-7 h-7 mx-auto bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center hover:bg-rose-100 hover:text-rose-600 transition-colors group"
                                title="Batalkan"
                              >
                                <span className="text-[10px] font-black group-hover:hidden">✓</span>
                                <X className="w-3.5 h-3.5 hidden group-hover:block" />
                              </button>
                            ) : (
                              <button 
                                onClick={() => handleOpenModal(student, b)}
                                className="w-7 h-7 mx-auto bg-slate-100 text-slate-400 hover:bg-indigo-600 hover:text-white rounded flex items-center justify-center transition-colors"
                                title="Tandai Lunas"
                              >
                                <span className="text-sm font-black">+</span>
                              </button>
                            )}
                          </td>
                        )
                      })}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="px-6 py-4 w-12 text-center">
                  <input 
                    type="checkbox" 
                    checked={filteredStudents.length > 0 && selectedIds.length === filteredStudents.length}
                    onChange={handleSelectAll}
                    className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                  />
                </th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">Nama Siswa</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap text-center">Periode</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap text-center">Status</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr><td colSpan={5} className="px-6 py-8 text-center text-sm text-slate-500">Memuat data...</td></tr>
              ) : filteredStudents.length === 0 ? (
                <tr><td colSpan={5} className="px-6 py-8 text-center text-sm text-slate-500">Tidak ada data siswa aktif.</td></tr>
              ) : (
                filteredStudents.map(student => {
                  const payment = payments.find(p => p.student_id === student.id);
                  const isLunas = !!payment;

                  return (
                    <tr key={student.id} className={\`hover:bg-slate-50/50 transition-colors \${selectedIds.includes(student.id) ? 'bg-indigo-50/30' : ''}\`}>
                      <td className="px-6 py-4 text-center">
                        <input 
                          type="checkbox" 
                          checked={selectedIds.includes(student.id)}
                          onChange={() => handleSelect(student.id)}
                          className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs shadow-sm">
                            {student.nama_lengkap.charAt(0)}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="text-sm font-bold text-slate-800">{student.nama_lengkap}</p>
                              
                            </div>
                            <p className="text-[10px] text-slate-500 font-mono mt-0.5">{student.nomor_whatsapp}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-3 py-1 rounded-full">
                          {selectedBulan} {selectedTahun}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        {isLunas ? (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-700 rounded-md text-[10px] font-black uppercase tracking-wider">
                            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span> Lunas
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-100 text-rose-700 rounded-md text-[10px] font-black uppercase tracking-wider">
                            <span className="w-1.5 h-1.5 bg-rose-500 rounded-full"></span> Belum Bayar
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-right">
                        {isLunas ? (
                          <div className="flex flex-col items-end gap-0.5">
                            <span className="text-xs font-black text-emerald-600 uppercase tracking-widest">Lunas</span>
                            <span className="text-[10px] font-bold text-slate-400">
                              {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(payment.nominal_dibayar)}
                            </span>
                          </div>
                        ) : (
                          <button 
                            onClick={() => handleOpenModal(student)}
                            disabled={isSubmitting}
                            className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-lg text-xs font-bold transition-colors shadow-sm"
                          >
                            Tandai Lunas
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payment Modal */}
      )}
      {/* Reminder Modal */}
      {isReminderModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <h3 className="text-sm font-bold text-slate-800">Kirim Reminder WA</h3>
                <select 
                  value={reminderBulan}
                  onChange={e => setReminderBulan(e.target.value)}
                  className="px-2 py-1 text-xs border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white font-semibold text-slate-700"
                >
                  {BULAN_OPTIONS.map(b => <option key={b} value={b}>{b}</option>)}
                </select>
              </div>
              <button onClick={() => setIsReminderModalOpen(false)} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-0 max-h-[60vh] overflow-y-auto">
              {belumLunasStudents.length === 0 ? (
                <div className="p-8 text-center">
                  <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                  <p className="text-sm font-bold text-slate-800">Semua Lunas!</p>
                  <p className="text-xs text-slate-500 mt-1">Tidak ada tagihan yang belum dibayar bulan ini.</p>
                </div>
              ) : (
                <ul className="divide-y divide-slate-100">
                  {belumLunasStudents.map(student => (
                    <li key={student.id} className="p-4 flex items-center justify-between hover:bg-slate-50/50 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs shadow-sm shrink-0">
                          {student.nama_lengkap.charAt(0)}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-slate-800 leading-tight">{student.nama_lengkap}</p>
                          <p className="text-[10px] text-slate-500 font-mono mt-0.5">{student.nomor_whatsapp}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => handleKirimWA(student)}
                        className="px-3 py-1.5 bg-emerald-100 text-emerald-700 hover:bg-emerald-200 hover:text-emerald-800 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors"
                      >
                        <MessageCircle className="w-3.5 h-3.5" /> Kirim WA
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end">
              <button onClick={() => setIsReminderModalOpen(false)} className="px-4 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors">
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {isModalOpen && selectedStudent && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-sm overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-800">Catat Pembayaran SPP</h3>
              <button onClick={() => setIsModalOpen(false)} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <form onSubmit={handleTandaiLunas} className="p-6 space-y-5">
              <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-4 flex gap-3">
                <div className="w-10 h-10 rounded-full bg-white text-indigo-700 flex items-center justify-center font-bold text-lg shrink-0 shadow-sm">
                  {selectedStudent.nama_lengkap.charAt(0)}
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-800 leading-tight">{selectedStudent.nama_lengkap}</p>
                  <p className="text-xs text-indigo-600 font-semibold mt-1">Periode: {selectedModalBulan || selectedBulan} {selectedTahun}</p>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Nominal Pembayaran (Rp)</label>
                <div className="relative">
                  <DollarSign className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="number" 
                    required
                    value={nominal}
                    onChange={e => setNominal(e.target.value)}
                    className="w-full pl-9 pr-4 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all shadow-sm font-bold text-slate-700"
                  />
                </div>
              </div>
              
              <div className="pt-2 flex gap-3">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-2.5 text-sm font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors">
                  Batal
                </button>
                <button type="submit" disabled={isSubmitting} className="flex-1 px-4 py-2.5 text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-70 rounded-lg transition-colors shadow-sm">
                  {isSubmitting ? 'Menyimpan...' : 'Simpan Lunas'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}`;

const BULAN_OPTIONS = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];
const YEAR_OPTIONS = Array.from({ length: 2045 - 2023 + 1 }, (_, i) => 2023 + i);

export default function DashboardView() {
  const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');
  const [copied, setCopied] = useState(false);
  
  // Dummy State for Preview
  const currentDate = new Date();
  const [selectedBulan, setSelectedBulan] = useState(BULAN_OPTIONS[currentDate.getMonth()]);
  const [selectedTahun, setSelectedTahun] = useState(currentDate.getFullYear().toString());
  const [searchQuery, setSearchQuery] = useState('');
  const [isReminderModalOpen, setIsReminderModalOpen] = useState(false);
  const [reminderBulan, setReminderBulan] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedModalBulan, setSelectedModalBulan] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [nominal, setNominal] = useState('100000');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const [students] = useState([
    { id: '1', nama_lengkap: 'Ahmad Fauzan Alfatih', nomor_whatsapp: '628123456789', nominal_spp: 100000 },
    { id: '2', nama_lengkap: 'Siti Humaira Khairunnisa', nomor_whatsapp: '628521122334', nominal_spp: 150000 },
    { id: '3', nama_lengkap: 'Budi Santoso Nugroho', nomor_whatsapp: '628998877665', nominal_spp: 100000 },
    { id: '4', nama_lengkap: 'Kayla Putri Adelia', nomor_whatsapp: '628131313131', nominal_spp: 120000 },
    { id: '5', nama_lengkap: 'Daffa Arya Pratama', nomor_whatsapp: '628221144556', nominal_spp: 100000 },
  ]);

  // Initial dummy payments
  const [payments, setPayments] = useState([
    { student_id: '1', bulan: BULAN_OPTIONS[currentDate.getMonth()], tahun: currentDate.getFullYear().toString(), nominal_dibayar: 100000 },
    { student_id: '3', bulan: BULAN_OPTIONS[currentDate.getMonth()], tahun: currentDate.getFullYear().toString(), nominal_dibayar: 100000 },
  ]);

  const handleCopy = () => {
    navigator.clipboard.writeText(nextJsCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenModal = (student: any, explicitBulan?: string) => {
    setSelectedModalBulan(explicitBulan || selectedBulan);
    setSelectedStudent(student);
    setNominal(student.nominal_spp?.toString() || '100000');
    setIsModalOpen(true);
  };

  const handleTandaiLunas = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent) return;
    setPayments([
      ...payments, 
      { 
        student_id: selectedStudent.id, 
        bulan: selectedModalBulan || selectedBulan, 
        tahun: selectedTahun, 
        nominal_dibayar: parseFloat(nominal) || 100000 
      }
    ]);
    setIsModalOpen(false);
    setSelectedStudent(null);
  };

  const handleBatalkanLunas = (studentId: string, explicitBulan?: string) => {
    if (!window.confirm('Mode Pratinjau: Yakin ingin membatalkan status lunas ini?')) return;
    setPayments(payments.filter(p => !(p.student_id === studentId && p.bulan === (explicitBulan || selectedBulan) && p.tahun === selectedTahun)));
  };

  const handleBulkLunas = () => {
    if (selectedIds.length === 0) return;
    if (!window.confirm(`Mode Pratinjau: Yakin ingin menandai ${selectedIds.length} siswa terpilih sebagai Lunas?`)) return;
    
    const newPayments = selectedIds.map(id => {
      const student = students.find(s => s.id === id);
      return {
        student_id: id,
        bulan: selectedModalBulan || selectedBulan,
        tahun: selectedTahun,
        nominal_dibayar: student?.nominal_spp || 100000
      };
    });

    setPayments([...payments, ...newPayments]);
    setSelectedIds([]);
  };

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedIds(filteredStudents.map(s => s.id));
    } else {
      setSelectedIds([]);
    }
  };

  const handleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]);
  };

  const fetchData = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSelectedIds([]);
    }, 600);
  };

  const filteredStudents = useMemo(() => {
    return students.filter(s => 
      s.nama_lengkap.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [students, searchQuery]);

  const belumLunasStudents = useMemo(() => {
    return filteredStudents.filter(s => !payments.some(p => p.student_id === s.id && p.bulan === (isReminderModalOpen ? reminderBulan : selectedBulan)));
  }, [filteredStudents, payments, isReminderModalOpen, reminderBulan, selectedBulan]);

  const handleKirimWA = (student: any) => {
    const message = `Halo Ayah/Bunda ${student.nama_lengkap}, mohon maaf mengingatkan untuk pembayaran SPP PAUD bulan ${reminderBulan || selectedBulan} ${selectedTahun} belum tercatat. Terima kasih.`;
    const url = `https://wa.me/${student.nomor_whatsapp}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-slate-50 font-sans">
      <div className="p-6 md:px-10 md:py-8 border-b border-slate-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Pembayaran SPP (Dashboard)</h2>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mt-1">Pratinjau & Kode Next.js</p>
        </div>
        <div className="flex bg-slate-100 p-1 rounded-lg">
          <button onClick={() => setViewMode('preview')} className={`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 ${viewMode === 'preview' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}`}>
            <Layout className="w-4 h-4" /> Preview UI
          </button>
          <button onClick={() => setViewMode('code')} className={`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 ${viewMode === 'code' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}`}>
            <Code2 className="w-4 h-4" /> Next.js Code
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6 md:p-10">
        {viewMode === 'preview' ? (
          <div className="max-w-5xl mx-auto space-y-6">
            {/* Filters */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-4">
              <div className="flex flex-col sm:flex-row gap-4 w-full">
                <button 
                  onClick={() => { setReminderBulan(selectedBulan === 'Semua Bulan' ? 'Januari' : selectedBulan); setIsReminderModalOpen(true); }}
                  className="px-4 py-2.5 text-sm font-bold rounded-lg flex items-center justify-center gap-2 transition-colors shadow-sm shrink-0 bg-emerald-600 text-white hover:bg-emerald-700"
                >
                  <MessageCircle className="w-4 h-4" />
                  Kirim Reminder ke Semua yang Belum Lunas
                </button>
                <div className="flex-1 relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="text" 
                    placeholder="Cari nama siswa..." 
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-4 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm" 
                  />
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex gap-2 items-center">
                  {selectedIds.length > 0 && (
                    <button 
                      onClick={handleBulkLunas}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold flex items-center gap-2 transition-colors shadow-sm"
                    >
                      <CheckSquare className="w-4 h-4" /> Tandai Lunas ({selectedIds.length})
                    </button>
                  )}
                  <button 
                    onClick={fetchData}
                    disabled={loading}
                    className="px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-sm font-bold items-center justify-center gap-2 transition-colors shadow-sm hidden sm:flex disabled:opacity-50"
                  >
                    <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Sync
                  </button>
                </div>
                <div className="relative w-full md:w-40">
                  <select 
                    value={selectedBulan}
                    onChange={e => setSelectedBulan(e.target.value)}
                    className="w-full pl-4 pr-8 py-2.5 text-sm border border-slate-200 rounded-lg appearance-none focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-indigo-900 bg-indigo-50/50 cursor-pointer shadow-sm"
                  >
                    <option value="Semua Bulan">Semua Bulan</option>
              {BULAN_OPTIONS.map(b => <option key={b} value={b}>{b}</option>)}
                  </select>
                </div>
                <div className="relative w-full md:w-32">
                  <select 
                    value={selectedTahun}
                    onChange={e => setSelectedTahun(e.target.value)}
                    className="w-full pl-4 pr-8 py-2.5 text-sm border border-slate-200 rounded-lg appearance-none focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-indigo-900 bg-indigo-50/50 cursor-pointer shadow-sm"
                  >
                    {YEAR_OPTIONS.map(y => (
                      <option key={y} value={y.toString()}>{y}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

{/* Matrix / Regular Table Switch */}
            {selectedBulan === 'Semua Bulan' ? (
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col overflow-hidden relative">
                <div className="overflow-x-auto">
                  <table className="w-full text-left min-w-[800px]">
                    <thead className="bg-slate-50">
                      <tr>
                        <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest sticky left-0 bg-slate-50 z-10 border-r border-slate-100 shadow-[1px_0_0_0_#f1f5f9]">Nama Siswa</th>
                        {BULAN_OPTIONS.map(b => (
                          <th key={b} className="px-3 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center min-w-[80px]">{b.slice(0, 3)}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredStudents.length === 0 ? (
                        <tr><td colSpan={13} className="px-6 py-8 text-center text-sm text-slate-500">Tidak ada data siswa.</td></tr>
                      ) : (
                        filteredStudents.map(student => (
                          <tr key={student.id} className="hover:bg-slate-50/50 transition-colors group/row">
                            <td className="px-6 py-3 sticky left-0 bg-white group-hover/row:bg-slate-50 z-10 border-r border-slate-100 shadow-[1px_0_0_0_#f1f5f9] transition-colors">
                              <p className="text-sm font-bold text-slate-800 truncate max-w-[150px]" title={student.nama_lengkap}>{student.nama_lengkap}</p>
                            </td>
                            {BULAN_OPTIONS.map(b => {
                              const payment = payments.find(p => p.student_id === student.id && p.bulan === b);
                              return (
                                <td key={b} className="px-2 py-2 text-center">
                                  {payment ? (
                                    <button 
                                      onClick={() => handleBatalkanLunas(student.id, b)}
                                      className="w-7 h-7 mx-auto bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center hover:bg-rose-100 hover:text-rose-600 transition-colors group"
                                      title="Batalkan"
                                    >
                                      <span className="text-[10px] font-black group-hover:hidden">✓</span>
                                      <X className="w-3.5 h-3.5 hidden group-hover:block" />
                                    </button>
                                  ) : (
                                    <button 
                                      onClick={() => handleOpenModal(student, b)}
                                      className="w-7 h-7 mx-auto bg-slate-100 text-slate-400 hover:bg-indigo-600 hover:text-white rounded flex items-center justify-center transition-colors"
                                      title="Tandai Lunas"
                                    >
                                      <span className="text-sm font-black">+</span>
                                    </button>
                                  )}
                                </td>
                              )
                            })}
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-slate-50/50 border-b border-slate-100">
                    <tr>
                      <th className="px-6 py-4 w-12 text-center">
                        <input 
                          type="checkbox" 
                          checked={filteredStudents.length > 0 && selectedIds.length === filteredStudents.length}
                          onChange={handleSelectAll}
                          className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                        />
                      </th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">Nama Siswa</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap text-center">Periode</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap text-center">Status</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap text-right">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {loading ? (
                      <tr><td colSpan={5} className="px-6 py-8 text-center text-sm text-slate-500">Memuat data...</td></tr>
                    ) : filteredStudents.length === 0 ? (
                      <tr><td colSpan={5} className="px-6 py-8 text-center text-sm text-slate-500">Siswa tidak ditemukan.</td></tr>
                    ) : (
                      filteredStudents.map(student => {
                        const payment = payments.find(p => p.student_id === student.id && p.bulan === selectedBulan && p.tahun === selectedTahun);
                        const isLunas = !!payment;

                        return (
                          <tr key={student.id} className={`hover:bg-slate-50/50 transition-colors ${selectedIds.includes(student.id) ? 'bg-indigo-50/30' : ''}`}>
                            <td className="px-6 py-4 text-center">
                              <input 
                                type="checkbox" 
                                checked={selectedIds.includes(student.id)}
                                onChange={() => handleSelect(student.id)}
                                className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                              />
                            </td>
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                <div className="w-9 h-9 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs shadow-sm">
                                  {student.nama_lengkap.charAt(0)}
                                </div>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <p className="text-sm font-bold text-slate-800">{student.nama_lengkap}</p>
                                    
                                  </div>
                                  <p className="text-[10px] text-slate-500 font-mono mt-0.5">{student.nomor_whatsapp}</p>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 text-center">
                              <span className="text-[11px] font-bold text-slate-600 bg-slate-100 px-3 py-1 rounded-full uppercase tracking-wider">
                                {selectedBulan} {selectedTahun}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-center">
                              {isLunas ? (
                                <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-700 rounded-md text-[10px] font-black uppercase tracking-wider">
                                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span> Lunas
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-100 text-rose-700 rounded-md text-[10px] font-black uppercase tracking-wider">
                                  <span className="w-1.5 h-1.5 bg-rose-500 rounded-full"></span> Belum Bayar
                                </span>
                              )}
                            </td>
                            <td className="px-6 py-4 text-right">
                              {isLunas ? (
                                <div className="flex flex-col items-end gap-1">
                                  <div className="flex flex-col items-end gap-0.5">
                                    <span className="text-xs font-black text-emerald-600 uppercase tracking-widest">Lunas</span>
                                    <span className="text-[10px] font-bold text-slate-400">
                                      {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(payment.nominal_dibayar)}
                                    </span>
                                  </div>
                                  <button 
                                    onClick={() => handleBatalkanLunas(student.id)}
                                    className="px-3 py-1 mt-1 bg-rose-500 hover:bg-rose-600 text-white rounded-md text-[10px] font-bold transition-colors shadow-sm uppercase tracking-widest"
                                  >
                                    Batalkan
                                  </button>
                                </div>
                              ) : (
                                <button 
                                  onClick={() => handleOpenModal(student)}
                                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-colors shadow-sm"
                                >
                                  Tandai Lunas
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            )}
            {/* Reminder Modal */}
      {isReminderModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-3">
                <h3 className="text-sm font-bold text-slate-800">Kirim Reminder WA</h3>
                <select 
                  value={reminderBulan}
                  onChange={e => setReminderBulan(e.target.value)}
                  className="px-2 py-1 text-xs border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white font-semibold text-slate-700"
                >
                  {BULAN_OPTIONS.map(b => <option key={b} value={b}>{b}</option>)}
                </select>
              </div>
              <button onClick={() => setIsReminderModalOpen(false)} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-0 max-h-[60vh] overflow-y-auto">
              {belumLunasStudents.length === 0 ? (
                <div className="p-8 text-center">
                  <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                  <p className="text-sm font-bold text-slate-800">Semua Lunas!</p>
                  <p className="text-xs text-slate-500 mt-1">Tidak ada tagihan yang belum dibayar bulan ini.</p>
                </div>
              ) : (
                <ul className="divide-y divide-slate-100">
                  {belumLunasStudents.map(student => (
                    <li key={student.id} className="p-4 flex items-center justify-between hover:bg-slate-50/50 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs shadow-sm shrink-0">
                          {student.nama_lengkap.charAt(0)}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-slate-800 leading-tight">{student.nama_lengkap}</p>
                          <p className="text-[10px] text-slate-500 font-mono mt-0.5">{student.nomor_whatsapp}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => handleKirimWA(student)}
                        className="px-3 py-1.5 bg-emerald-100 text-emerald-700 hover:bg-emerald-200 hover:text-emerald-800 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors"
                      >
                        <MessageCircle className="w-3.5 h-3.5" /> Kirim WA
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end">
              <button onClick={() => setIsReminderModalOpen(false)} className="px-4 py-2 text-sm font-bold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors">
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

            {isModalOpen && selectedStudent && (
              <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
                <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-sm overflow-hidden animate-in zoom-in-95 duration-200">
                  <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                    <h3 className="text-sm font-bold text-slate-800">Catat Pembayaran SPP</h3>
                    <button onClick={() => setIsModalOpen(false)} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <form onSubmit={handleTandaiLunas} className="p-6 space-y-5">
                    <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-4 flex gap-3 shadow-sm">
                      <div className="w-10 h-10 rounded-full bg-white text-indigo-700 flex items-center justify-center font-bold text-lg shrink-0 shadow-sm">
                        {selectedStudent.nama_lengkap.charAt(0)}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-800 leading-tight">{selectedStudent.nama_lengkap}</p>
                        <p className="text-xs text-indigo-600 font-bold mt-1">Periode: {selectedModalBulan || selectedBulan} {selectedTahun}</p>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Nominal Pembayaran (Rp)</label>
                      <div className="relative">
                        <DollarSign className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input 
                          type="number" 
                          required
                          value={nominal}
                          onChange={e => setNominal(e.target.value)}
                          className="w-full pl-9 pr-4 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all shadow-sm font-bold text-slate-700"
                        />
                      </div>
                    </div>
                    
                    <div className="pt-2 flex gap-3">
                      <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-2.5 text-sm font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors">
                        Batal
                      </button>
                      <button type="submit" className="flex-1 px-4 py-2.5 text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors shadow-sm">
                        Simpan Lunas
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="max-w-4xl mx-auto relative group">
            <div className="mb-4">
              <h3 className="text-lg font-bold text-slate-800">app/dashboard/page.tsx</h3>
              <p className="text-xs text-slate-500">Salin kode ini ke dalam proyek Next.js Anda (App Router).</p>
            </div>
            <button
              onClick={handleCopy}
              className="absolute right-4 top-16 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors text-xs font-bold flex items-center gap-2 shadow-sm"
            >
              {copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? 'Tersalin!' : 'Copy Code'}
            </button>
            <pre className="bg-slate-50 border border-slate-200 text-slate-800 p-6 pt-16 rounded-2xl overflow-x-auto text-xs font-mono shadow-inner">
              <code>{nextJsCode}</code>
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}
