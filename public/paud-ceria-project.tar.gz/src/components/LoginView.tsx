import React, { useState } from 'react';
import { Layout, Code2, Copy, CheckCircle2, Mail, Lock, LogIn } from 'lucide-react';

const nextJsCode = `'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
// Gunakan @supabase/ssr untuk otentikasi aman di Next.js App Router
import { createBrowserClient } from '@supabase/ssr';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  // Initialize Supabase browser client
  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      setError(error.message);
      setLoading(false);
    } else {
      router.push('/dashboard');
      router.refresh();
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 font-sans">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="bg-indigo-900 p-8 text-center">
          <div className="w-16 h-16 bg-amber-400 rounded-2xl mx-auto flex items-center justify-center text-indigo-900 font-bold text-3xl mb-4 shadow-sm">P</div>
          <h1 className="text-2xl font-bold text-white">PAUD Ceria</h1>
          <p className="text-indigo-200 text-sm mt-1">Sistem Manajemen SPP</p>
        </div>
        
        <form onSubmit={handleLogin} className="p-8 space-y-6">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-100 text-rose-600 rounded-lg text-sm font-medium">
              {error}
            </div>
          )}
          
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Email Admin</label>
            <div className="relative">
              <Mail className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="email" 
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="admin@paudceria.com" 
                className="w-full pl-10 pr-4 py-3 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
              />
            </div>
          </div>
          
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Password</label>
            <div className="relative">
              <Lock className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="password" 
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••" 
                className="w-full pl-10 pr-4 py-3 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
              />
            </div>
          </div>

          <button 
            type="submit" 
            disabled={loading}
            className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-colors shadow-md disabled:opacity-70"
          >
            {loading ? 'Memverifikasi...' : (
              <>
                <LogIn className="w-5 h-5" /> Masuk ke Dashboard
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
`;

export default function LoginView({ 
    onLogin, 
    schoolName = 'PAUD Ceria', 
    schoolLogo = '' 
  }: { 
    onLogin?: () => void; 
    schoolName?: string; 
    schoolLogo?: string; 
  }) {
  const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');
  const [copied, setCopied] = useState(false);

  // Dummy state for preview
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleCopy = () => {
    navigator.clipboard.writeText(nextJsCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFakeLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    setTimeout(() => {
      setLoading(false);
      if (onLogin) {
        onLogin();
      } else {
        setError('Mode Pratinjau: Simulasi verifikasi selesai. Di aplikasi asli, Anda akan diarahkan ke Dashboard.');
      }
    }, 1500);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-slate-50 font-sans">
      <div className="p-6 md:px-10 md:py-8 border-b border-slate-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Halaman Login</h2>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mt-1">Pratinjau & Kode Next.js</p>
        </div>
        <div className="flex bg-slate-100 p-1 rounded-lg">
          <button onClick={() => setViewMode('preview')} className={`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 ${viewMode === 'preview' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}`}>
            <Layout className="w-4 h-4" /> Preview UI
          </button>
          <button onClick={() => setViewMode('code')} className={`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 ${viewMode === 'code' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}`}>
            <Code2 className="w-4 h-4" /> Next.js Code
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6 md:p-10">
        {viewMode === 'preview' ? (
          <div className="w-full max-w-md mx-auto rounded-2xl shadow-xl border border-slate-200 overflow-hidden bg-white mt-10">
            <div className="bg-indigo-900 p-8 text-center">
              {schoolLogo ? (
                <div className="w-16 h-16 rounded-2xl mx-auto flex items-center justify-center mb-4 shadow-sm overflow-hidden bg-white">
                  <img src={schoolLogo} alt="Logo" className="w-full h-full object-cover" />
                </div>
              ) : (
                <div className="w-16 h-16 bg-amber-400 rounded-2xl mx-auto flex items-center justify-center text-indigo-900 font-bold text-3xl mb-4 shadow-sm">
                  {schoolName ? schoolName.charAt(0).toUpperCase() : 'P'}
                </div>
              )}
              <h1 className="text-2xl font-bold text-white">{schoolName}</h1>
              <p className="text-indigo-200 text-sm mt-1">Sistem Manajemen SPP</p>
            </div>
            
            <form onSubmit={handleFakeLogin} className="p-8 space-y-6">
              {error && (
                <div className="p-3 bg-indigo-50 border border-indigo-100 text-indigo-700 rounded-lg text-sm font-medium">
                  {error}
                </div>
              )}
              
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Email Admin</label>
                <div className="relative">
                  <Mail className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="email" 
                    required
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="admin@paudceria.com" 
                    className="w-full pl-10 pr-4 py-3 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
                  />
                </div>
              </div>
              
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Password</label>
                <div className="relative">
                  <Lock className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="password" 
                    required
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="••••••••" 
                    className="w-full pl-10 pr-4 py-3 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
                  />
                </div>
              </div>

              <button 
                type="submit" 
                disabled={loading}
                className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-colors shadow-md disabled:opacity-70"
              >
                {loading ? 'Memverifikasi...' : (
                  <>
                    <LogIn className="w-5 h-5" /> Masuk ke Dashboard
                  </>
                )}
              </button>
            </form>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto relative group">
            <div className="mb-4">
              <h3 className="text-lg font-bold text-slate-800">app/login/page.tsx</h3>
              <p className="text-xs text-slate-500">Salin kode ini ke dalam proyek Next.js Anda (App Router).</p>
            </div>
            <button
              onClick={handleCopy}
              className="absolute right-4 top-16 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors text-xs font-bold flex items-center gap-2 shadow-sm"
            >
              {copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? 'Tersalin!' : 'Copy Code'}
            </button>
            <pre className="bg-slate-50 border border-slate-200 text-slate-800 p-6 pt-16 rounded-2xl overflow-x-auto text-xs font-mono shadow-inner">
              <code>{nextJsCode}</code>
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}
