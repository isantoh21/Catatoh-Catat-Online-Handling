import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabaseClient';
import { Download, TrendingUp, TrendingDown, Wallet, Users, UserMinus, Code2, Layout, CheckCircle2, Copy, Trash2, Plus } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType } from 'docx';
import { saveAs } from 'file-saver';
import { FileText, FileDown } from 'lucide-react';

const BULAN_OPTIONS = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];
const YEAR_OPTIONS = Array.from({ length: 2045 - 2023 + 1 }, (_, i) => 2023 + i);

export default function ReportsView() {
  const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');
  const [copied, setCopied] = useState(false);
  
  const currentDate = new Date();
  const [selectedBulan, setSelectedBulan] = useState(BULAN_OPTIONS[currentDate.getMonth()]);
  const [selectedTahun, setSelectedTahun] = useState(currentDate.getFullYear().toString());
  
  const [loading, setLoading] = useState(false);
  const [students, setStudents] = useState<any[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [expenses, setExpenses] = useState<any[]>([]);

  // Expense Form
  const [newExpenseName, setNewExpenseName] = useState('');
  const [newExpenseAmount, setNewExpenseAmount] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchData();

    const paymentsChannel = supabase
      .channel('realtime-reports-payments')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'payments' }, () => {
        fetchData();
      })
      .subscribe();
      
    const expensesChannel = supabase
      .channel('realtime-reports-expenses')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'expenses' }, () => {
        fetchData();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(paymentsChannel);
      supabase.removeChannel(expensesChannel);
    };
  }, [selectedTahun]); // Re-fetch all data for the year when year changes

  const fetchData = async () => {
    setLoading(true);

    // Fetch active students for metrics
    const { data: studentsData } = await supabase
      .from('students')
      .select('id, nama_lengkap, nominal_spp')
      .eq('status_aktif', true);
      
    if (studentsData) setStudents(studentsData);

    // Fetch payments for selected year
    const { data: paymentsData } = await supabase
      .from('payments')
      .select('*, students(nama_lengkap)')
      .eq('tahun', parseInt(selectedTahun));
      
    if (paymentsData) setPayments(paymentsData);

    // Fetch expenses for selected year
    const { data: expensesData } = await supabase
      .from('expenses')
      .select('*')
      .eq('tahun', parseInt(selectedTahun))
      .order('tanggal', { ascending: false });

    if (expensesData) setExpenses(expensesData);

    setLoading(false);
  };

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExpenseName || !newExpenseAmount) return;
    
    setIsSubmitting(true);
    const today = new Date().toISOString().split('T')[0];
    
    const { error } = await supabase.from('expenses').insert([{
      nama_pengeluaran: newExpenseName,
      nominal: parseInt(newExpenseAmount.replace(/\D/g, '')),
      tanggal: today,
      bulan: selectedBulan,
      tahun: parseInt(selectedTahun)
    }]);

    if (!error) {
      setNewExpenseName('');
      setNewExpenseAmount('');
      fetchData();
    } else {
      alert('Gagal menambah pengeluaran: ' + error.message);
    }
    setIsSubmitting(false);
  };

  const handleDeleteExpense = async (id: string) => {
    if (!window.confirm('Hapus data pengeluaran ini?')) return;
    const { error } = await supabase.from('expenses').delete().eq('id', id);
    if (!error) {
      fetchData();
    }
  };

  // 1. Data for Monthly Balance (Selected Month)
  const monthlyPayments = payments.filter(p => p.bulan === selectedBulan);
  const monthlyExpenses = expenses.filter(e => e.bulan === selectedBulan);

  const totalPemasukan = monthlyPayments.reduce((sum, p) => sum + Number(p.nominal_dibayar), 0);
  const totalPengeluaran = monthlyExpenses.reduce((sum, e) => sum + Number(e.nominal), 0);
  const labaRugi = totalPemasukan - totalPengeluaran;

  const totalLunas = monthlyPayments.length;
  const totalBelumLunas = students.length - totalLunas;

  const transactions = monthlyPayments.map(p => ({
    nama_lengkap: p.students?.nama_lengkap || 'Unknown',
    tanggal_bayar: p.tanggal_bayar,
    nominal_dibayar: p.nominal_dibayar
  }));

  // 2. Data for Yearly Chart
  const chartData = BULAN_OPTIONS.map(bulan => {
    const bPayments = payments.filter(p => p.bulan === bulan);
    const bExpenses = expenses.filter(e => e.bulan === bulan);
    
    return {
      name: bulan.substring(0, 3), // Jan, Feb, Mar
      Pemasukan: bPayments.reduce((sum, p) => sum + Number(p.nominal_dibayar), 0),
      Pengeluaran: bExpenses.reduce((sum, e) => sum + Number(e.nominal), 0)
    };
  });

  const formatRupiah = (num: number) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(num);
  };

  const handleExportPDF = () => {
    const doc = new jsPDF();
    const title = `Laporan Keuangan PAUD - ${selectedBulan} ${selectedTahun}`;
    
    doc.setFontSize(16);
    doc.text(title, 14, 15);
    
    doc.setFontSize(11);
    doc.text(`Total Pemasukan: ${formatRupiah(totalPemasukan)}`, 14, 25);
    doc.text(`Total Pengeluaran: ${formatRupiah(totalPengeluaran)}`, 14, 32);
    doc.text(`Laba / Rugi Bersih: ${formatRupiah(labaRugi)}`, 14, 39);

    autoTable(doc, {
      startY: 45,
      head: [['Kategori', 'Keterangan/Siswa', 'Tanggal', 'Nominal']],
      body: [
        ...transactions.map(t => ['Pemasukan', t.nama_lengkap, new Date(t.tanggal_bayar).toLocaleDateString('id-ID'), formatRupiah(t.nominal_dibayar)]),
        ...monthlyExpenses.map(e => ['Pengeluaran', e.nama_pengeluaran, new Date(e.tanggal).toLocaleDateString('id-ID'), formatRupiah(e.nominal)])
      ],
    });

    doc.save(`Laporan_Keuangan_${selectedBulan}_${selectedTahun}.pdf`);
  };

  const handleExportDOCX = async () => {
    const doc = new Document({
      sections: [
        {
          properties: {},
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: `Laporan Keuangan PAUD - ${selectedBulan} ${selectedTahun}`,
                  bold: true,
                  size: 32,
                }),
              ],
            }),
            new Paragraph({ text: "" }),
            new Paragraph({ text: `Total Pemasukan: ${formatRupiah(totalPemasukan)}` }),
            new Paragraph({ text: `Total Pengeluaran: ${formatRupiah(totalPengeluaran)}` }),
            new Paragraph({ text: `Laba / Rugi Bersih: ${formatRupiah(labaRugi)}` }),
            new Paragraph({ text: "" }),
            new Paragraph({
              children: [new TextRun({ text: "Rincian Transaksi", bold: true, size: 24 })],
            }),
            new Paragraph({ text: "" }),
            new Table({
              width: { size: 100, type: WidthType.PERCENTAGE },
              rows: [
                new TableRow({
                  children: [
                    new TableCell({ children: [new Paragraph({ text: "Kategori" })] }),
                    new TableCell({ children: [new Paragraph({ text: "Keterangan/Siswa" })] }),
                    new TableCell({ children: [new Paragraph({ text: "Tanggal" })] }),
                    new TableCell({ children: [new Paragraph({ text: "Nominal" })] }),
                  ],
                }),
                ...transactions.map(
                  (t) =>
                    new TableRow({
                      children: [
                        new TableCell({ children: [new Paragraph("Pemasukan")] }),
                        new TableCell({ children: [new Paragraph(t.nama_lengkap)] }),
                        new TableCell({ children: [new Paragraph(new Date(t.tanggal_bayar).toLocaleDateString('id-ID'))] }),
                        new TableCell({ children: [new Paragraph(formatRupiah(t.nominal_dibayar))] }),
                      ],
                    })
                ),
                ...monthlyExpenses.map(
                  (e) =>
                    new TableRow({
                      children: [
                        new TableCell({ children: [new Paragraph("Pengeluaran")] }),
                        new TableCell({ children: [new Paragraph(e.nama_pengeluaran)] }),
                        new TableCell({ children: [new Paragraph(new Date(e.tanggal).toLocaleDateString('id-ID'))] }),
                        new TableCell({ children: [new Paragraph(formatRupiah(e.nominal))] }),
                      ],
                    })
                ),
              ],
            }),
          ],
        },
      ],
    });

    const blob = await Packer.toBlob(doc);
    saveAs(blob, `Laporan_Keuangan_${selectedBulan}_${selectedTahun}.docx`);
  };

  const nextJsCode = `'use client';
// Source code removed for brevity in preview
`;

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-slate-50 font-sans">
      <div className="p-6 md:px-10 md:py-8 border-b border-slate-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Laporan Keuangan & Laba Rugi</h2>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mt-1">Pantau Arus Kas PAUD</p>
        </div>
        <div className="flex bg-slate-100 p-1 rounded-lg">
          <button onClick={() => setViewMode('preview')} className={`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 ${viewMode === 'preview' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}`}>
            <Layout className="w-4 h-4" /> Preview UI
          </button>
          <button onClick={() => setViewMode('code')} className={`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 ${viewMode === 'code' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}`}>
            <Code2 className="w-4 h-4" /> Next.js Code
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6 md:p-10">
        {viewMode === 'preview' ? (
          <div className="max-w-6xl mx-auto space-y-8">
            
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex flex-wrap gap-2">
                <button onClick={handleExportPDF} className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold flex items-center gap-2 shadow-sm transition-colors">
                  <FileDown className="w-4 h-4" /> Export PDF
                </button>
                <button onClick={handleExportDOCX} className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold flex items-center gap-2 shadow-sm transition-colors">
                  <FileText className="w-4 h-4" /> Export DOCX
                </button>
              </div>
              <div className="flex justify-end gap-4">
              <select 
                value={selectedBulan}
                onChange={e => setSelectedBulan(e.target.value)}
                className="pl-4 pr-8 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-indigo-900 bg-white shadow-sm"
              >
                {BULAN_OPTIONS.map(b => <option key={b} value={b}>{b}</option>)}
              </select>
              <select 
                value={selectedTahun}
                onChange={e => setSelectedTahun(e.target.value)}
                className="pl-4 pr-8 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-indigo-900 bg-white shadow-sm"
              >
                {YEAR_OPTIONS.map(y => (
                  <option key={y} value={y.toString()}>{y}</option>
                ))}
              </select>
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Pemasukan (SPP)</p>
                  <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg">
                    <TrendingUp className="w-5 h-5" />
                  </div>
                </div>
                <p className="text-3xl font-black text-slate-800">{formatRupiah(totalPemasukan)}</p>
                <div className="mt-4 flex gap-4 text-xs font-bold">
                  <span className="text-emerald-600 bg-emerald-50 px-2 py-1 rounded">{totalLunas} Lunas</span>
                  <span className="text-rose-600 bg-rose-50 px-2 py-1 rounded">{totalBelumLunas} Belum</span>
                </div>
              </div>

              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Pengeluaran</p>
                  <div className="p-2 bg-rose-100 text-rose-600 rounded-lg">
                    <TrendingDown className="w-5 h-5" />
                  </div>
                </div>
                <p className="text-3xl font-black text-slate-800">{formatRupiah(totalPengeluaran)}</p>
                <div className="mt-4 flex gap-4 text-xs font-bold">
                  <span className="text-slate-500">{monthlyExpenses.length} Transaksi</span>
                </div>
              </div>

              <div className={`p-6 rounded-2xl border shadow-sm ${labaRugi >= 0 ? 'bg-indigo-600 border-indigo-700 text-white' : 'bg-rose-600 border-rose-700 text-white'}`}>
                <div className="flex items-center justify-between mb-4">
                  <p className="text-xs font-bold uppercase tracking-wider opacity-80">Laba / Rugi Bersih</p>
                  <div className="p-2 bg-white/20 rounded-lg">
                    <Wallet className="w-5 h-5" />
                  </div>
                </div>
                <p className="text-3xl font-black">{formatRupiah(labaRugi)}</p>
                <div className="mt-4 flex gap-4 text-xs font-bold">
                  <span className="bg-white/20 px-2 py-1 rounded">Bulan {selectedBulan} {selectedTahun}</span>
                </div>
              </div>
            </div>

            {/* Chart Section */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <h3 className="text-sm font-bold text-slate-700 mb-6 flex items-center gap-2">
                <span className="w-2 h-2 bg-indigo-500 rounded-full"></span>
                Grafik Keuangan Tahun {selectedTahun}
              </h3>
              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={chartData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} dy={10} />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fontSize: 12, fill: '#64748b' }}
                      tickFormatter={(value) => `Rp ${value / 1000}k`}
                      dx={-10}
                    />
                    <Tooltip 
                      formatter={(value: number) => formatRupiah(value)}
                      cursor={{fill: '#f8fafc'}}
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    />
                    <Legend iconType="circle" wrapperStyle={{ paddingTop: '20px' }}/>
                    <Bar dataKey="Pemasukan" fill="#10b981" radius={[4, 4, 0, 0]} maxBarSize={40} />
                    <Bar dataKey="Pengeluaran" fill="#f43f5e" radius={[4, 4, 0, 0]} maxBarSize={40} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Income Statement Detailed Table */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Pemasukan Table */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
                <div className="p-4 border-b border-slate-100 bg-slate-50/50">
                  <h3 className="text-sm font-bold text-slate-700 flex items-center gap-2">
                    <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
                    Rincian Pemasukan SPP
                  </h3>
                </div>
                <div className="flex-1 overflow-auto max-h-96">
                  <table className="w-full text-left">
                    <thead className="bg-slate-50 sticky top-0">
                      <tr>
                        <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Siswa</th>
                        <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Nominal</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {transactions.length === 0 ? (
                        <tr><td colSpan={2} className="px-6 py-8 text-center text-sm text-slate-500">Belum ada pemasukan.</td></tr>
                      ) : (
                        transactions.map((t, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                            <td className="px-6 py-4">
                              <p className="text-sm font-bold text-slate-800">{t.nama_lengkap}</p>
                              <p className="text-[10px] text-slate-500 font-semibold">{new Date(t.tanggal_bayar).toLocaleDateString('id-ID')}</p>
                            </td>
                            <td className="px-6 py-4 text-sm font-bold text-slate-800 text-right">
                              {formatRupiah(t.nominal_dibayar)}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Pengeluaran Table */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
                <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-700 flex items-center gap-2">
                    <span className="w-2 h-2 bg-rose-500 rounded-full"></span>
                    Rincian Pengeluaran
                  </h3>
                </div>
                
                {/* Form Add Expense */}
                <form onSubmit={handleAddExpense} className="p-4 border-b border-slate-100 bg-slate-50 flex gap-2">
                  <input 
                    type="text"
                    required
                    value={newExpenseName}
                    onChange={e => setNewExpenseName(e.target.value)}
                    placeholder="Nama Pengeluaran (Cth: Listrik)"
                    className="flex-1 px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
                  />
                  <input 
                    type="number"
                    required
                    value={newExpenseAmount}
                    onChange={e => setNewExpenseAmount(e.target.value)}
                    placeholder="Nominal (Rp)"
                    className="w-32 px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
                  />
                  <button 
                    type="submit"
                    disabled={isSubmitting}
                    className="p-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors shadow-sm disabled:opacity-50"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </form>

                <div className="flex-1 overflow-auto max-h-[300px]">
                  <table className="w-full text-left">
                    <thead className="bg-slate-50 sticky top-0">
                      <tr>
                        <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Keterangan</th>
                        <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Nominal</th>
                        <th className="px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Aksi</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {monthlyExpenses.length === 0 ? (
                        <tr><td colSpan={3} className="px-6 py-8 text-center text-sm text-slate-500">Belum ada pengeluaran.</td></tr>
                      ) : (
                        monthlyExpenses.map((e, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                            <td className="px-6 py-4">
                              <p className="text-sm font-bold text-slate-800">{e.nama_pengeluaran}</p>
                              <p className="text-[10px] text-slate-500 font-semibold">{new Date(e.tanggal).toLocaleDateString('id-ID')}</p>
                            </td>
                            <td className="px-6 py-4 text-sm font-bold text-slate-800 text-right">
                              {formatRupiah(e.nominal)}
                            </td>
                            <td className="px-4 py-4 text-right">
                              <button 
                                onClick={() => handleDeleteExpense(e.id)}
                                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto relative group">
            <div className="mb-4">
              <h3 className="text-lg font-bold text-slate-800">app/reports/page.tsx</h3>
              <p className="text-xs text-slate-500">Salin kode ini ke dalam proyek Next.js Anda (App Router).</p>
            </div>
            <pre className="bg-slate-50 border border-slate-200 text-slate-800 p-6 pt-16 rounded-2xl overflow-x-auto text-xs font-mono shadow-inner">
              <code>{nextJsCode}</code>
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}
