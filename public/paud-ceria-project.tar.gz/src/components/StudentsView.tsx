import React, { useState, useRef } from 'react';
import { Plus, X, Search, CheckCircle2, Copy, Code2, Layout, Upload, Edit2, Trash2, Download, RefreshCw } from 'lucide-react';
import Papa from 'papaparse';

const nextJsCode = `'use client';

import { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabaseClient';
import { Plus, X, Upload, Edit2, Trash2, Download, RefreshCw } from 'lucide-react';
import Papa from 'papaparse';

export default function StudentsPage() {
  const [students, setStudents] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [nama, setNama] = useState('');
  const [whatsapp, setWhatsapp] = useState('62');
  const [nominalSpp, setNominalSpp] = useState('100000');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [isImporting, setIsImporting] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchStudents();

    const channel = supabase
      .channel('realtime-students')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'students' }, (payload) => {
        console.log('Real-time update on students:', payload);
        fetchStudents();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchStudents = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('students')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (data) setStudents(data);
    setLoading(false);
  };

  const resetModal = () => {
    setIsModalOpen(false);
    setEditingId(null);
    setNama('');
    setWhatsapp('62');
    setNominalSpp('100000');
    setError('');
  };

  const handleAddStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!whatsapp.startsWith('62')) {
      setError('Nomor WhatsApp harus diawali dengan 62');
      return;
    }
    
    if (!nominalSpp || isNaN(Number(nominalSpp))) {
      setError('Nominal SPP harus berupa angka yang valid');
      return;
    }

    if (editingId) {
      const { error: updateError } = await supabase.from('students')
        .update({ nama_lengkap: nama, nomor_whatsapp: whatsapp, nominal_spp: Number(nominalSpp) })
        .eq('id', editingId);
        
      if (updateError) {
        setError(updateError.message);
      } else {
        resetModal();
        fetchStudents();
      }
    } else {
      const { error: insertError } = await supabase.from('students').insert([
        { nama_lengkap: nama, nomor_whatsapp: whatsapp, nominal_spp: Number(nominalSpp), status_aktif: true }
      ]);

      if (insertError) {
        setError(insertError.message);
      } else {
        resetModal();
        fetchStudents();
      }
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Yakin ingin menghapus data siswa ini?')) return;
    const { error } = await supabase.from('students').delete().eq('id', id);
    if (error) alert('Gagal menghapus: ' + error.message);
    else fetchStudents();
  };

  const handleBulkDelete = async () => {
    if (selectedIds.length === 0) return;
    if (!window.confirm(\`Yakin ingin menghapus \${selectedIds.length} data siswa terpilih?\`)) return;
    
    const { error } = await supabase.from('students').delete().in('id', selectedIds);
    if (error) {
      alert('Gagal menghapus: ' + error.message);
    } else {
      setSelectedIds([]);
      fetchStudents();
    }
  };

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedIds(students.map((s: any) => s.id));
    } else {
      setSelectedIds([]);
    }
  };

  const handleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]);
  };

  const openEditModal = (student: any) => {
    setEditingId(student.id);
    setNama(student.nama_lengkap);
    setWhatsapp(student.nomor_whatsapp);
    setNominalSpp(student.nominal_spp?.toString() || '100000');
    setIsModalOpen(true);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        const parsedData = results.data as any[];
        
        // Validasi header CSV
        if (parsedData.length > 0 && (!parsedData[0].hasOwnProperty('nama_lengkap') || !parsedData[0].hasOwnProperty('nomor_whatsapp'))) {
          alert('Format CSV salah. Pastikan header adalah: nama_lengkap, nomor_whatsapp, nominal_spp (opsional)');
          setIsImporting(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
          return;
        }

        const validStudents = parsedData
          .map(row => {
            let wa = String(row.nomor_whatsapp).replace(/\\D/g, '');
            if (wa && !wa.startsWith('62')) wa = '62' + wa;
            
            // Ambil nominal_spp, default 100000 jika kosong atau tidak valid
            let nominalSpp = 100000;
            if (row.nominal_spp && !isNaN(Number(row.nominal_spp))) {
              nominalSpp = Number(row.nominal_spp);
            }

            return {
              nama_lengkap: row.nama_lengkap,
              nomor_whatsapp: wa,
              nominal_spp: nominalSpp,
              status_aktif: true
            };
          })
          .filter(s => s.nama_lengkap && s.nomor_whatsapp);

        if (validStudents.length === 0) {
          alert('Tidak ada data valid untuk diimport.');
          setIsImporting(false);
          return;
        }

        const { error: insertError } = await supabase.from('students').insert(validStudents);
        
        if (insertError) {
          alert('Gagal mengimport: ' + insertError.message);
        } else {
          alert('Berhasil mengimport ' + validStudents.length + ' siswa!');
          fetchStudents();
        }
        
        setIsImporting(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      },
      error: (err) => {
        alert('Gagal membaca file CSV: ' + err.message);
        setIsImporting(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    });
  };

  const downloadTemplate = () => {
    const csvContent = "nama_lengkap,nomor_whatsapp,nominal_spp\nAhmad,628123456789,150000\n";
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'template_siswa.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-6 md:p-8 max-w-5xl mx-auto space-y-6 font-sans">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Data Siswa</h1>
          <p className="text-sm text-slate-500">Kelola daftar siswa PAUD</p>
        </div>
        <div className="flex gap-3">
          {selectedIds.length > 0 && (
            <button 
              onClick={handleBulkDelete}
              className="px-4 py-2 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 rounded-lg text-sm font-bold flex items-center gap-2 transition-colors shadow-sm"
            >
              <Trash2 className="w-4 h-4" /> Hapus Terpilih ({selectedIds.length})
            </button>
          )}
          <button 
            onClick={fetchStudents}
            disabled={loading}
            className="px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-sm font-bold items-center justify-center gap-2 transition-colors shadow-sm hidden sm:flex disabled:opacity-50"
          >
            <RefreshCw className={\`w-4 h-4 \${loading ? 'animate-spin' : ''}\`} /> Sync
          </button>
          <button 
            onClick={downloadTemplate}
            className="px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-sm font-bold items-center justify-center gap-2 transition-colors shadow-sm hidden sm:flex"
          >
            <Download className="w-4 h-4" /> Template CSV
          </button>
          <input 
            type="file" 
            accept=".csv" 
            className="hidden" 
            ref={fileInputRef} 
            onChange={handleFileUpload} 
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={isImporting}
            className="px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-colors shadow-sm disabled:opacity-70"
          >
            <Upload className="w-4 h-4" /> 
            {isImporting ? 'Mengimport...' : 'Import CSV'}
          </button>
          <button 
            onClick={() => setIsModalOpen(true)} 
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" /> Tambah Siswa
          </button>
        </div>
      </div>

      <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-xl">
        <h4 className="text-xs font-bold text-indigo-800 uppercase tracking-wider mb-1">Panduan Import CSV</h4>
        <p className="text-sm text-indigo-600">Pastikan file CSV Anda memiliki header baris pertama persis seperti ini: <strong>nama_lengkap, nomor_whatsapp, nominal_spp</strong>. (Contoh: <i>Ahmad, 628123456789, 150000</i>)</p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50/50 border-b border-slate-100">
              <tr>
                <th className="px-6 py-4 w-12 text-center">
                  <input 
                    type="checkbox" 
                    checked={students.length > 0 && selectedIds.length === students.length}
                    onChange={handleSelectAll}
                    className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                  />
                </th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">Nama Siswa</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">WhatsApp</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">Nominal SPP</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">Status</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right whitespace-nowrap">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr><td colSpan={6} className="px-6 py-8 text-center text-sm text-slate-500">Memuat data...</td></tr>
              ) : students.length === 0 ? (
                <tr><td colSpan={6} className="px-6 py-8 text-center text-sm text-slate-500">Belum ada data siswa.</td></tr>
              ) : (
                students.map((s: any) => (
                  <tr key={s.id} className={\`hover:bg-slate-50/50 transition-colors \${selectedIds.includes(s.id) ? 'bg-indigo-50/30' : ''}\`}>
                    <td className="px-6 py-4 text-center">
                      <input 
                        type="checkbox" 
                        checked={selectedIds.includes(s.id)}
                        onChange={() => handleSelect(s.id)}
                        className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-xs">
                          {s.nama_lengkap.charAt(0)}
                        </div>
                        <span className="text-sm font-bold text-slate-800">{s.nama_lengkap}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-xs font-mono text-slate-600">{s.nomor_whatsapp}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm font-bold text-slate-700">
                        {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(s.nominal_spp || 0)}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      {s.status_aktif ? (
                        <span className="px-2.5 py-1 bg-emerald-100 text-emerald-700 rounded-md text-[10px] font-black uppercase tracking-wider">Aktif</span>
                      ) : (
                        <span className="px-2.5 py-1 bg-slate-100 text-slate-500 rounded-md text-[10px] font-black uppercase tracking-wider">Nonaktif</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-right flex items-center justify-end gap-2">
                      <button onClick={() => openEditModal(s)} className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors" title="Edit">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleDelete(s.id)} className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors" title="Hapus">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Tambah Siswa */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h3 className="text-sm font-bold text-slate-800">{editingId ? 'Edit Data Siswa' : 'Tambah Siswa Baru'}</h3>
              <button onClick={() => resetModal()} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddStudent} className="p-6 space-y-4">
              {error && (
                <div className="p-3 bg-rose-50 border border-rose-100 text-rose-600 rounded-lg text-xs font-medium">
                  {error}
                </div>
              )}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">Nama Lengkap</label>
                <input 
                  type="text" required value={nama} onChange={e => setNama(e.target.value)}
                  placeholder="Masukkan nama lengkap" 
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">Nomor WhatsApp</label>
                <input 
                  type="tel" required value={whatsapp} 
                  onChange={e => {
                    const val = e.target.value.replace(/\\D/g, '');
                    setWhatsapp(val.length > 0 && !val.startsWith('62') ? '62' + val : val);
                  }}
                  placeholder="628..." 
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">Nominal SPP (Rp)</label>
                <input 
                  type="number" required value={nominalSpp} 
                  onChange={e => setNominalSpp(e.target.value)}
                  placeholder="100000" 
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                />
              </div>
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => resetModal()} className="flex-1 px-4 py-2 text-sm font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors">
                  Batal
                </button>
                <button type="submit" className="flex-1 px-4 py-2 text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors shadow-sm">
                  {editingId ? 'Simpan Perubahan' : 'Simpan Siswa'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}`;

export default function StudentsView() {
  const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');
  const [copied, setCopied] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [nama, setNama] = useState('');
  const [whatsapp, setWhatsapp] = useState('62');
  const [nominalSpp, setNominalSpp] = useState('100000');
  const [error, setError] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  
  const [students, setStudents] = useState([
    { id: '1', nama_lengkap: 'Ahmad Fauzan Alfatih', nomor_whatsapp: '628123456789', nominal_spp: 100000, status_aktif: true },
    { id: '2', nama_lengkap: 'Siti Humaira Khairunnisa', nomor_whatsapp: '628521122334', nominal_spp: 150000, status_aktif: true },
  ]);

  const [isImporting, setIsImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleCopy = () => {
    navigator.clipboard.writeText(nextJsCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const resetModal = () => {
    setIsModalOpen(false);
    setEditingId(null);
    setNama('');
    setWhatsapp('62');
    setNominalSpp('100000');
    setError('');
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!whatsapp.startsWith('62')) {
      setError('Nomor WhatsApp harus diawali dengan 62 (contoh: 62812...)');
      return;
    }
    if (whatsapp.length < 10) {
      setError('Nomor WhatsApp tidak valid (terlalu pendek)');
      return;
    }
    if (!nominalSpp || isNaN(Number(nominalSpp))) {
      setError('Nominal SPP harus berupa angka yang valid');
      return;
    }

    if (editingId) {
      setStudents(students.map(s => s.id === editingId ? {
        ...s,
        nama_lengkap: nama,
        nomor_whatsapp: whatsapp,
        nominal_spp: Number(nominalSpp)
      } : s));
    } else {
      setStudents([{ id: Date.now().toString(), nama_lengkap: nama, nomor_whatsapp: whatsapp, nominal_spp: Number(nominalSpp), status_aktif: true }, ...students]);
    }
    resetModal();
  };

  const handleDelete = (id: string) => {
    if (!window.confirm('Mode Pratinjau: Yakin ingin menghapus data siswa ini?')) return;
    setStudents(students.filter(s => s.id !== id));
  };

  const handleBulkDelete = () => {
    if (selectedIds.length === 0) return;
    if (!window.confirm(`Mode Pratinjau: Yakin ingin menghapus ${selectedIds.length} data siswa terpilih?`)) return;
    setStudents(students.filter(s => !selectedIds.includes(s.id)));
    setSelectedIds([]);
  };

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedIds(students.map((s: any) => s.id));
    } else {
      setSelectedIds([]);
    }
  };

  const handleSelect = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]);
  };

  const fetchStudents = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSelectedIds([]);
    }, 600);
  };

  const openEditModal = (student: any) => {
    setEditingId(student.id);
    setNama(student.nama_lengkap);
    setWhatsapp(student.nomor_whatsapp);
    setNominalSpp(student.nominal_spp?.toString() || '100000');
    setIsModalOpen(true);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const parsedData = results.data as any[];
        
        if (parsedData.length > 0 && (!parsedData[0].hasOwnProperty('nama_lengkap') || !parsedData[0].hasOwnProperty('nomor_whatsapp'))) {
          alert('Mode Pratinjau: Format CSV salah. Pastikan header adalah: nama_lengkap, nomor_whatsapp, nominal_spp (opsional)');
          setIsImporting(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
          return;
        }

        const validStudents = parsedData
          .map(row => {
            let wa = String(row.nomor_whatsapp).replace(/\\D/g, '');
            if (wa && !wa.startsWith('62')) wa = '62' + wa;
            
            let nomSpp = 100000;
            if (row.nominal_spp && !isNaN(Number(row.nominal_spp))) {
              nomSpp = Number(row.nominal_spp);
            }

            return {
              id: Math.random().toString(36).substr(2, 9),
              nama_lengkap: row.nama_lengkap,
              nomor_whatsapp: wa,
              nominal_spp: nomSpp,
              status_aktif: true
            };
          })
          .filter(s => s.nama_lengkap && s.nomor_whatsapp);

        if (validStudents.length === 0) {
          alert('Mode Pratinjau: Tidak ada data valid untuk diimport.');
          setIsImporting(false);
          return;
        }

        setStudents([...validStudents, ...students]);
        alert('Mode Pratinjau: Berhasil mengimport ' + validStudents.length + ' siswa!');
        
        setIsImporting(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      },
      error: (err) => {
        alert('Mode Pratinjau: Gagal membaca file CSV - ' + err.message);
        setIsImporting(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    });
  };

  const downloadTemplate = () => {
    const csvContent = "nama_lengkap,nomor_whatsapp,nominal_spp\nAhmad,628123456789,150000\n";
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'template_siswa.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-slate-50 font-sans">
      <div className="p-6 md:px-10 md:py-8 border-b border-slate-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Data Siswa</h2>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mt-1">Pratinjau & Kode Next.js</p>
        </div>
        <div className="flex bg-slate-100 p-1 rounded-lg">
          <button onClick={() => setViewMode('preview')} className={`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 ${viewMode === 'preview' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}`}>
            <Layout className="w-4 h-4" /> Preview UI
          </button>
          <button onClick={() => setViewMode('code')} className={`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 ${viewMode === 'code' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}`}>
            <Code2 className="w-4 h-4" /> Next.js Code
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-6 md:p-10">
        {viewMode === 'preview' ? (
          <div className="max-w-5xl mx-auto space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input type="text" placeholder="Cari siswa..." className="pl-9 pr-4 py-2.5 text-sm border border-slate-200 rounded-lg w-full sm:w-64 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-white shadow-sm transition-all" />
              </div>
              <div className="flex gap-3">
                {selectedIds.length > 0 && (
                  <button 
                    onClick={handleBulkDelete}
                    className="px-4 py-2 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 rounded-lg text-sm font-bold flex items-center gap-2 transition-colors shadow-sm"
                  >
                    <Trash2 className="w-4 h-4" /> Hapus Terpilih ({selectedIds.length})
                  </button>
                )}
                <button 
                  onClick={fetchStudents}
                  disabled={loading}
                  className="px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-sm font-bold items-center justify-center gap-2 transition-colors shadow-sm hidden sm:flex disabled:opacity-50"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Simpan ke Database
                </button>
                <button 
                  onClick={downloadTemplate}
                  className="px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-sm font-bold items-center justify-center gap-2 transition-colors shadow-sm hidden sm:flex"
                >
                  <Download className="w-4 h-4" /> Template CSV
                </button>
                <input 
                  type="file" 
                  accept=".csv" 
                  className="hidden" 
                  ref={fileInputRef} 
                  onChange={handleFileUpload} 
                />
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isImporting}
                  className="px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-colors shadow-sm disabled:opacity-70"
                >
                  <Upload className="w-4 h-4" /> 
                  {isImporting ? 'Mengimport...' : 'Import CSV'}
                </button>
                <button onClick={() => setIsModalOpen(true)} className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-colors shadow-sm">
                  <Plus className="w-4 h-4" /> Tambah Siswa
                </button>
              </div>
            </div>

            <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-xl">
              <h4 className="text-xs font-bold text-indigo-800 uppercase tracking-wider mb-1">Panduan Import CSV</h4>
              <p className="text-sm text-indigo-600">Pastikan file CSV Anda memiliki header baris pertama persis seperti ini: <strong>nama_lengkap, nomor_whatsapp, nominal_spp</strong> (opsional). (Contoh: <i>Ahmad, 628123456789, 150000</i>)</p>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-slate-50/50 border-b border-slate-100">
                    <tr>
                      <th className="px-6 py-4 w-12 text-center">
                        <input 
                          type="checkbox" 
                          checked={students.length > 0 && selectedIds.length === students.length}
                          onChange={handleSelectAll}
                          className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                        />
                      </th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">Nama Siswa</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">WhatsApp</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">Nominal SPP</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest whitespace-nowrap">Status</th>
                      <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right whitespace-nowrap">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {loading ? (
                      <tr><td colSpan={6} className="px-6 py-8 text-center text-sm text-slate-500">Memuat data...</td></tr>
                    ) : students.map(s => (
                      <tr key={s.id} className={`hover:bg-slate-50/50 transition-colors ${selectedIds.includes(s.id) ? 'bg-indigo-50/30' : ''}`}>
                        <td className="px-6 py-4 text-center">
                          <input 
                            type="checkbox" 
                            checked={selectedIds.includes(s.id)}
                            onChange={() => handleSelect(s.id)}
                            className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                          />
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs shadow-sm">
                              {s.nama_lengkap.charAt(0)}
                            </div>
                            <span className="text-sm font-bold text-slate-800">{s.nama_lengkap}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-xs font-mono text-indigo-600">{s.nomor_whatsapp}</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm font-bold text-slate-700">
                            {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(s.nominal_spp || 0)}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          {s.status_aktif ? (
                            <span className="px-2.5 py-1 bg-emerald-100 text-emerald-700 rounded-md text-[10px] font-black uppercase tracking-wider">Aktif</span>
                          ) : (
                            <span className="px-2.5 py-1 bg-slate-100 text-slate-500 rounded-md text-[10px] font-black uppercase tracking-wider">Nonaktif</span>
                          )}
                        </td>
                        <td className="px-6 py-4 text-right flex items-center justify-end gap-2">
                          <button onClick={() => openEditModal(s)} className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors" title="Edit">
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button onClick={() => handleDelete(s.id)} className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors" title="Hapus">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                    {students.length === 0 && (
                      <tr>
                        <td colSpan={6} className="px-6 py-8 text-center text-slate-500 text-sm">Belum ada data siswa.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto relative group">
            <div className="mb-4">
              <h3 className="text-lg font-bold text-slate-800">app/students/page.tsx</h3>
              <p className="text-xs text-slate-500">Salin kode ini ke dalam proyek Next.js Anda (App Router).</p>
            </div>
            <button
              onClick={handleCopy}
              className="absolute right-4 top-16 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors text-xs font-bold flex items-center gap-2 shadow-sm"
            >
              {copied ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? 'Tersalin!' : 'Copy Code'}
            </button>
            <pre className="bg-slate-50 border border-slate-200 text-slate-800 p-6 pt-16 rounded-2xl overflow-x-auto text-xs font-mono shadow-inner">
              <code>{nextJsCode}</code>
            </pre>
          </div>
        )}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h3 className="text-sm font-bold text-slate-800">{editingId ? 'Edit Data Siswa' : 'Tambah Siswa Baru'}</h3>
              <button onClick={() => resetModal()} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAdd} className="p-6 space-y-5">
              {error && (
                <div className="p-3 bg-rose-50 border border-rose-100 text-rose-600 rounded-lg text-xs font-medium">
                  {error}
                </div>
              )}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Nama Lengkap</label>
                <input 
                  type="text" 
                  required
                  value={nama}
                  onChange={e => setNama(e.target.value)}
                  placeholder="Masukkan nama lengkap" 
                  className="w-full px-4 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all shadow-sm"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Nomor WhatsApp</label>
                <div className="relative">
                  <input 
                    type="tel" 
                    required
                    value={whatsapp}
                    onChange={e => {
                      const val = e.target.value.replace(/\D/g, '');
                      if (!val.startsWith('62') && val.length > 0) {
                        setWhatsapp('62' + val);
                      } else {
                        setWhatsapp(val);
                      }
                    }}
                    placeholder="628..." 
                    className="w-full px-4 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all font-mono shadow-sm"
                  />
                </div>
                <p className="text-[10px] text-slate-400 font-medium">Pastikan diawali dengan 62 (Contoh: 628123456789)</p>
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Nominal SPP (Rp)</label>
                <input 
                  type="number" 
                  required
                  value={nominalSpp}
                  onChange={e => setNominalSpp(e.target.value)}
                  placeholder="100000" 
                  className="w-full px-4 py-2.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all font-mono shadow-sm"
                />
              </div>
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => resetModal()} className="flex-1 px-4 py-2.5 text-sm font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors">
                  Batal
                </button>
                <button type="submit" className="flex-1 px-4 py-2.5 text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors shadow-sm">
                  {editingId ? 'Simpan Perubahan' : 'Simpan Siswa'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
