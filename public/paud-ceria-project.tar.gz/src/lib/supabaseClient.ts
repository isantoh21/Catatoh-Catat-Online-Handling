import { createClient } from '@supabase/supabase-js';

// URL dan Anon Key didapatkan dari dashboard Supabase Anda (Project Settings -> API)
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || (import.meta as any).env?.VITE_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || 'placeholder_key';

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn("Supabase URL atau Anon Key belum dikonfigurasi.");
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
