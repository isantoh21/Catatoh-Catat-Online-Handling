const fs = require('fs');
let code = fs.readFileSync('src/components/DashboardView.tsx', 'utf-8');

code = code.replace(
  /const handleBatalkanLunas = async \(studentId: string, explicitBulan\?: string\) => {[\s\S]*?setIsSubmitting\(false\);\n  };/m,
  `const handleBatalkanLunas = async (studentId: string, explicitBulan?: string) => {
    if (!window.confirm('Yakin ingin membatalkan status lunas ini?')) return;
    setIsSubmitting(true);
    const { data, error } = await supabase
      .from('payments')
      .delete()
      .eq('student_id', studentId)
      .eq('bulan', explicitBulan || selectedBulan)
      .eq('tahun', parseInt(selectedTahun))
      .select();
      
    if (error) {
      alert('Gagal membatalkan lunas: ' + error.message);
    } else if (data && data.length === 0) {
      alert('Gagal menghapus: Supabase RLS memblokir aksi hapus, ATAU data tidak ditemukan. Pastikan Anda mengizinkan operasi DELETE di Supabase.');
    } else {
      await fetchData();
    }
    setIsSubmitting(false);
  };`
);

fs.writeFileSync('src/components/DashboardView.tsx', code);
