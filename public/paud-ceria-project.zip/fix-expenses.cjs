const fs = require('fs');
if(fs.existsSync('src/components/ExpensesView.tsx')) {
  let code = fs.readFileSync('src/components/ExpensesView.tsx', 'utf-8');
  code = code.replace(
    /const handleDelete = async \(id: string\) => {[\s\S]*?};/m,
    `const handleDelete = async (id: string) => {
      if (!window.confirm('Yakin ingin menghapus data pengeluaran ini?')) return;
      setLoading(true);
      const { data, error } = await supabase.from('expenses').delete().eq('id', id).select();
      if (error) alert('Gagal menghapus: ' + error.message);
      else if (data && data.length === 0) alert('Gagal menghapus: Supabase memblokir aksi ini.');
      else fetchExpenses();
      setLoading(false);
    };`
  );
  fs.writeFileSync('src/components/ExpensesView.tsx', code);
}
