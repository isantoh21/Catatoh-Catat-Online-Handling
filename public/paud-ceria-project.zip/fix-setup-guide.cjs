const fs = require('fs');
let code = fs.readFileSync('src/components/SetupGuide.tsx', 'utf-8');

code = code.replace(
  /CREATE TABLE students \([\s\S]*?\);/m,
  `CREATE TABLE students (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL DEFAULT auth.uid(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  nama_lengkap TEXT NOT NULL,
  nomor_whatsapp TEXT NOT NULL CHECK (nomor_whatsapp LIKE '62%'),
  nominal_spp NUMERIC NOT NULL DEFAULT 100000,
  status_aktif BOOLEAN DEFAULT true
);`
);

code = code.replace(
  /CREATE TABLE expenses \([\s\S]*?\);/m,
  `CREATE TABLE expenses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL DEFAULT auth.uid(),
  nama_pengeluaran TEXT NOT NULL,
  nominal NUMERIC NOT NULL,
  tanggal DATE NOT NULL,
  bulan TEXT NOT NULL,
  tahun INT NOT NULL
);`
);

code = code.replace(
  /CREATE TABLE payments \([\s\S]*?\);/m,
  `CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL DEFAULT auth.uid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  bulan TEXT NOT NULL,
  tahun INT NOT NULL,
  nominal_dibayar NUMERIC NOT NULL,
  tanggal_bayar DATE NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('Lunas', 'Belum'))
);`
);

code = code.replace(
  /CREATE POLICY "Allow ALL on students for authenticated users"[\s\S]*?WITH CHECK \(true\);/m,
  `CREATE POLICY "Isolasi data students" ON students FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);`
);

code = code.replace(
  /CREATE POLICY "Allow ALL on payments for authenticated users"[\s\S]*?WITH CHECK \(true\);/m,
  `CREATE POLICY "Isolasi data payments" ON payments FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);`
);

code = code.replace(
  /CREATE POLICY "Allow ALL on expenses for authenticated users"[\s\S]*?WITH CHECK \(true\);/m,
  `CREATE POLICY "Isolasi data expenses" ON expenses FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);`
);

fs.writeFileSync('src/components/SetupGuide.tsx', code);
