const fs = require('fs');
let code = fs.readFileSync('src/components/StudentsView.tsx', 'utf-8');

code = code.replace(
  /const handleDelete = async \(id: string\) => {[\s\S]*?setLoading\(false\);\n  };/m,
  `const handleDelete = async (id: string) => {
    if (!window.confirm('Yakin ingin menghapus data siswa ini?')) return;
    setLoading(true);
    // Hapus pembayaran terkait dulu
    await supabase.from('payments').delete().eq('student_id', id);
    
    // Hapus siswa dan pastikan ada yang terhapus dengan .select()
    const { data, error } = await supabase.from('students').delete().eq('id', id).select();
    
    if (error) {
      alert('Gagal menghapus: ' + error.message);
    } else if (data && data.length === 0) {
      alert('Gagal menghapus: Supabase memblokir aksi ini. Pastikan Policy DELETE diizinkan di Supabase!');
    } else {
      fetchStudents();
    }
    setLoading(false);
  };`
);

code = code.replace(
  /const handleBulkDelete = async \(\) => {[\s\S]*?setLoading\(false\);\n  };/m,
  `const handleBulkDelete = async () => {
    if (selectedIds.length === 0) return;
    if (!window.confirm(\`Yakin ingin menghapus \${selectedIds.length} data siswa terpilih?\`)) return;
    
    setLoading(true);
    await supabase.from('payments').delete().in('student_id', selectedIds);
    const { data, error } = await supabase.from('students').delete().in('id', selectedIds).select();
    
    if (error) {
      alert('Gagal menghapus: ' + error.message);
    } else if (data && data.length === 0) {
      alert('Gagal menghapus: Supabase memblokir aksi ini. Pastikan Policy DELETE diizinkan di Supabase!');
    } else {
      setSelectedIds([]);
      fetchStudents();
    }
    setLoading(false);
  };`
);

fs.writeFileSync('src/components/StudentsView.tsx', code);
