const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

if (!code.includes("Database")) {
    code = code.replace("LogOut } from 'lucide-react';", "LogOut, Database, Wifi, WifiOff } from 'lucide-react';");
}

const statusState = `  const [activeTab, setActiveTab] = useState<'dashboard' | 'students' | 'reports' | 'settings'>('dashboard');
  const [dbStatus, setDbStatus] = useState<'checking' | 'connected' | 'error'>('checking');`;
code = code.replace("  const [activeTab, setActiveTab] = useState<'dashboard' | 'students' | 'reports' | 'settings'>('dashboard');", statusState);

const statusEffect = `    const savedLogo = localStorage.getItem('schoolLogo');
    if (savedLogo) setSchoolLogo(savedLogo);

    const checkDb = async () => {
      const url = import.meta.env?.VITE_SUPABASE_URL || '';
      if (!url || url.includes('placeholder')) {
        setDbStatus('error');
        return;
      }
      try {
        const { error } = await supabase.from('siswa').select('id', { count: 'exact', head: true });
        if (error && error.message && error.message.includes('Failed to fetch')) {
          setDbStatus('error');
        } else {
          setDbStatus('connected');
        }
      } catch (err) {
        setDbStatus('error');
      }
    };
    checkDb();`;
code = code.replace("    const savedLogo = localStorage.getItem('schoolLogo');\n    if (savedLogo) setSchoolLogo(savedLogo);", statusEffect);

const statusBarUI = `      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* DB Connection Status Bar */}
        <div className={\`px-4 py-2 text-xs font-bold flex items-center justify-between shrink-0 \${dbStatus === 'connected' ? 'bg-emerald-500 text-white' : dbStatus === 'checking' ? 'bg-slate-200 text-slate-500' : 'bg-rose-500 text-white'}\`}>
          <div className="flex items-center gap-2">
            {dbStatus === 'connected' ? <Wifi className="w-4 h-4" /> : dbStatus === 'checking' ? <Database className="w-4 h-4 animate-pulse" /> : <WifiOff className="w-4 h-4" />}
            <span>
              {dbStatus === 'connected' ? 'Terhubung ke Database (Supabase)' : dbStatus === 'checking' ? 'Mengecek Koneksi Database...' : 'Tidak Terhubung ke Database (Cek koneksi internet atau .env.local)'}
            </span>
          </div>
          {dbStatus === 'error' && (
            <span className="text-[10px] bg-black/20 px-2 py-1 rounded-md uppercase tracking-wider">Offline</span>
          )}
        </div>`;
code = code.replace("      <main className=\"flex-1 flex flex-col overflow-hidden relative\">", statusBarUI);

fs.writeFileSync('src/App.tsx', code);
console.log('Fixed App.tsx');
