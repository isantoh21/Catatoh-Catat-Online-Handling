const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

code = code.replace("const url = import.meta.env?.VITE_SUPABASE_URL || '';", "const url = (import.meta as any).env?.VITE_SUPABASE_URL || '';");

fs.writeFileSync('src/App.tsx', code);
console.log('Fixed App.tsx TS Error');
