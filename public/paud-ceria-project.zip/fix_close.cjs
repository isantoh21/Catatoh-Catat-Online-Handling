const fs = require('fs');
let content = fs.readFileSync('src/components/ReportsView.tsx', 'utf8');

content = content.replace(
  `              </select>
            </div>

            {/* Metrics */}`,
  `              </select>
              </div>
            </div>

            {/* Metrics */}`
);

fs.writeFileSync('src/components/ReportsView.tsx', content);
