const fs = require('fs');

let content = fs.readFileSync('src/components/DashboardView.tsx', 'utf8');

// The exported DashboardView has this:
// const [students] = useState<any[]>([]);
// const [payments, setPayments] = useState<any[]>([]);
// Let's replace the `const fetchData = () => { ... }` with the real one.

content = content.replace(
  /const \[students\] = useState<any\[\]>\(\[\]\);/,
  `const [students, setStudents] = useState<any[]>([]);`
);

let realFetch = `
  useEffect(() => {
    fetchData();
    const studentsChannel = supabase
      .channel('realtime-students')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'students' }, () => {
        fetchData();
      })
      .subscribe();
    const paymentsChannel = supabase
      .channel('realtime-payments')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'payments' }, () => {
        fetchData();
      })
      .subscribe();
    return () => {
      supabase.removeChannel(studentsChannel);
      supabase.removeChannel(paymentsChannel);
    };
  }, []);

  const fetchData = async () => {
    setLoading(true);
    const { data: studentsData } = await supabase.from('students').select('*');
    if (studentsData) setStudents(studentsData);
    
    const { data: paymentsData } = await supabase.from('payments').select('*');
    if (paymentsData) setPayments(paymentsData);
    
    setLoading(false);
    setSelectedIds([]);
  };

  const handleSubmitSpp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent || !nominal) return;
    setIsSubmitting(true);
    
    const newPayment = {
      student_id: selectedStudent.id,
      bulan: selectedModalBulan || selectedBulan,
      tahun: parseInt(selectedTahun),
      nominal_dibayar: parseFloat(nominal),
      tanggal_bayar: new Date().toISOString().split('T')[0],
      status: 'Lunas'
    };
    
    await supabase.from('payments').insert([newPayment]);
    setIsSubmitting(false);
    setIsModalOpen(false);
    fetchData();
  };

  const handleBulkLunas = async () => {
    if (selectedIds.length === 0) return;
    if (!window.confirm(\`Yakin ingin menandai \${selectedIds.length} siswa terpilih sebagai Lunas?\`)) return;
    
    setLoading(true);
    const newPayments = selectedIds.map(id => ({
      student_id: id,
      bulan: selectedBulan,
      tahun: parseInt(selectedTahun),
      nominal_dibayar: students.find(s => s.id === id)?.nominal_spp || 100000,
      tanggal_bayar: new Date().toISOString().split('T')[0],
      status: 'Lunas'
    }));
    
    await supabase.from('payments').insert(newPayments);
    setSelectedIds([]);
    fetchData();
  };
`;

// Replace dummy fetchData
content = content.replace(
  /const fetchData = \(\) => \{\n\s*setLoading\(true\);\n\s*setTimeout\(\(\) => \{\n\s*setLoading\(false\);\n\s*setSelectedIds\(\[\]\);\n\s*\}, 600\);\n\s*\};/,
  realFetch
);

content = content.replace(
  /const handleSubmitSpp = \(e: React.FormEvent\) => \{\n\s*e.preventDefault\(\);\n\s*setIsSubmitting\(true\);\n\s*setTimeout\(\(\) => \{\n\s*setIsSubmitting\(false\);\n\s*setIsModalOpen\(false\);\n\s*\}, 1000\);\n\s*\};/,
  ''
);

content = content.replace(
  /const handleBulkLunas = \(\) => \{\n\s*if \(selectedIds\.length === 0\) return;\n\s*setLoading\(true\);\n\s*setTimeout\(\(\) => \{\n\s*setLoading\(false\);\n\s*setSelectedIds\(\[\]\);\n\s*\}, 1000\);\n\s*\};/,
  ''
);

// add import for supabase if not present in exported component part
if (!content.includes("import { supabase } from '../lib/supabaseClient';")) {
  content = content.replace("import React,", "import { supabase } from '../lib/supabaseClient';\nimport React,");
}

fs.writeFileSync('src/components/DashboardView.tsx', content);
console.log("Patched DashboardView.tsx");
