const fs = require('fs');
let content = fs.readFileSync('src/components/ReportsView.tsx', 'utf8');

// I'll search for the messed up div and replace it.
content = content.replace(
  `</div>
<div className="flex justify-end gap-4">`,
  `<div className="flex justify-end gap-4">`
);

fs.writeFileSync('src/components/ReportsView.tsx', content);
