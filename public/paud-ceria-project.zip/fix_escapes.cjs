const fs = require('fs');
['src/components/DashboardView.tsx', 'src/components/StudentsView.tsx', 'src/components/ReportsView.tsx'].forEach(file => {
  if (fs.existsSync(file)) {
    let content = fs.readFileSync(file, 'utf8');
    content = content.replace(/\\`/g, '`');
    content = content.replace(/\\\$/g, '$');
    fs.writeFileSync(file, content);
    console.log('Fixed escapes in', file);
  }
});
