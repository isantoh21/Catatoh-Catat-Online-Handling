const fs = require('fs');

let dashboard = fs.readFileSync('src/components/DashboardView.tsx', 'utf8');
if (!dashboard.includes("import React")) {
  dashboard = "import React from 'react';\n" + dashboard;
}
if (!dashboard.includes("CheckCircle2")) {
  dashboard = dashboard.replace("Square, Save", "Square, Save, CheckCircle2");
}
fs.writeFileSync('src/components/DashboardView.tsx', dashboard);

let students = fs.readFileSync('src/components/StudentsView.tsx', 'utf8');
if (!students.includes("import React")) {
  students = "import React from 'react';\n" + students;
}
fs.writeFileSync('src/components/StudentsView.tsx', students);

// Delete backup files
if (fs.existsSync('DashboardView_orig.tsx')) fs.unlinkSync('DashboardView_orig.tsx');
if (fs.existsSync('src/components/DashboardView_orig.tsx')) fs.unlinkSync('src/components/DashboardView_orig.tsx');

console.log('Fixed imports and deleted backups.');
