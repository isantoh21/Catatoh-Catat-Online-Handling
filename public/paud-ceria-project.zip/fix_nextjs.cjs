const fs = require('fs');
let code = fs.readFileSync('src/components/DashboardView.tsx', 'utf8');

code = code.replace(
  /<button\\n                                     onClick=\{\(\) => handleBatalkanLunas\(student\.id\)\}\\n                                    className="text-\[10px\] font-bold text-slate-400 hover:text-rose-500 transition-colors uppercase tracking-widest"\\n                                  >\\n                                    Batalkan\\n                                  <\/button>/g,
  '<button\\n                                     onClick={() => handleBatalkanLunas(student.id)}\\n                                    className="px-3 py-1 mt-1 bg-rose-500 hover:bg-rose-600 text-white rounded-md text-[10px] font-bold transition-colors shadow-sm uppercase tracking-widest"\\n                                  >\\n                                    Batalkan\\n                                  </button>'
);

fs.writeFileSync('src/components/DashboardView.tsx', code);
