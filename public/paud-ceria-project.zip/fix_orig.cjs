const fs = require('fs');
const lines = fs.readFileSync('src/components/DashboardView_orig.tsx', 'utf8').split('\n');

// 1. We want lines 1-3, and then the string from line 6 to 524
let newContent = lines.slice(5, 524).join('\n'); // lines 6 to 524

// 2. Rename DashboardPage to DashboardView
newContent = newContent.replace('export default function DashboardPage()', 'export default function DashboardView()');

// 3. Fix the backticks since they were escaped inside the string
newContent = newContent.replace(/\\`/g, '`');
newContent = newContent.replace(/\\\$/g, '$');

fs.writeFileSync('src/components/DashboardView.tsx', newContent);
console.log('Restored and extracted DashboardView successfully.');
