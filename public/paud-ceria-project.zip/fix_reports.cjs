const fs = require('fs');
let content = fs.readFileSync('src/components/ReportsView.tsx', 'utf8');

// Remove states
content = content.replace(/const \[viewMode, setViewMode\] = useState<'preview' \| 'code'>\('preview'\);\n/, '');
content = content.replace(/const \[copied, setCopied\] = useState\(false\);\n/, '');

// Remove nextJsCode
content = content.replace(/const nextJsCode = `[\s\S]*?`;/, '');

// Remove toggle buttons
const toggleButtons = `<div className="flex bg-slate-100 p-1 rounded-lg">
          <button onClick={() => setViewMode('preview')} className={\`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 \${viewMode === 'preview' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}\`}>
            <Layout className="w-4 h-4" /> Preview UI
          </button>
          <button onClick={() => setViewMode('code')} className={\`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 \${viewMode === 'code' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}\`}>
            <Code2 className="w-4 h-4" /> Next.js Code
          </button>
        </div>`;
content = content.replace(toggleButtons, '');

// Remove {viewMode === 'preview' ? (
content = content.replace(/\{viewMode === 'preview' \? \(\s*/, '');

// Remove the else block and closing brace
const elseBlockRegex = /\) : \(\s*<div className="max-w-4xl mx-auto relative group">[\s\S]*?<\/div>\s*\)\}\s*<\/div>\s*<\/div>\s*\);\s*\}/;
content = content.replace(elseBlockRegex, '      </div>\n    </div>\n  );\n}');

fs.writeFileSync('src/components/ReportsView.tsx', content);
console.log('Fixed ReportsView.tsx');
