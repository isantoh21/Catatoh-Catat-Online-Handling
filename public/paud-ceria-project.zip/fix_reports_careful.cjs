const fs = require('fs');
let code = fs.readFileSync('src/components/ReportsView.tsx', 'utf8');

// 1. Remove the states
code = code.replace("  const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');\n", "");
code = code.replace("  const [copied, setCopied] = useState(false);\n", "");

// 2. Remove the nextJsCode variable completely.
const nextJsCodeStart = code.indexOf("  const nextJsCode = `'use client';");
const nextJsCodeEnd = code.indexOf("`;", nextJsCodeStart) + 3;
if (nextJsCodeStart !== -1) {
  code = code.slice(0, nextJsCodeStart) + code.slice(nextJsCodeEnd);
}

// 3. Remove the button block
const buttonsStr = `<div className="flex bg-slate-100 p-1 rounded-lg">
          <button onClick={() => setViewMode('preview')} className={\`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 \${viewMode === 'preview' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}\`}>
            <Layout className="w-4 h-4" /> Preview UI
          </button>
          <button onClick={() => setViewMode('code')} className={\`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 \${viewMode === 'code' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}\`}>
            <Code2 className="w-4 h-4" /> Next.js Code
          </button>
        </div>`;
code = code.replace(buttonsStr, "");

// 4. Remove the `{viewMode === 'preview' ? (`
code = code.replace("{viewMode === 'preview' ? (\n          <div className=\"max-w-6xl mx-auto space-y-8\">", "<div className=\"max-w-6xl mx-auto space-y-8\">");

// 5. Remove the `) : (` and the whole code section at the end.
// We can find where `) : (` for the viewMode starts. It's right after the main content `</div>` that closes `<div className="max-w-6xl mx-auto space-y-8">`.
const elseBlock = `        ) : (
          <div className="max-w-4xl mx-auto relative group">
            <div className="mb-4">
              <h3 className="text-lg font-bold text-slate-800">app/reports/page.tsx</h3>
              <p className="text-xs text-slate-500">Salin kode ini ke dalam proyek Next.js Anda (App Router).</p>
            </div>
            <pre className="bg-slate-50 border border-slate-200 text-slate-800 p-6 pt-16 rounded-2xl overflow-x-auto text-xs font-mono shadow-inner">
              <code>{nextJsCode}</code>
            </pre>
          </div>
        )}`;
code = code.replace(elseBlock, "");

fs.writeFileSync('src/components/ReportsView.tsx', code);
console.log('Fixed carefully');
