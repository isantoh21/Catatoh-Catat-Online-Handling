const fs = require('fs');
let content = fs.readFileSync('ReportsView_orig.tsx', 'utf8');

// Remove states
content = content.replace(/const \[viewMode, setViewMode\] = useState<'preview' \| 'code'>\('preview'\);\n/, '');
content = content.replace(/const \[copied, setCopied\] = useState\(false\);\n/, '');

// Remove nextJsCode
content = content.replace(/const nextJsCode = `[\s\S]*?`;/, '');

// Remove toggle buttons
const toggleButtons = `<div className="flex bg-slate-100 p-1 rounded-lg">
          <button onClick={() => setViewMode('preview')} className={\`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 \${viewMode === 'preview' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}\`}>
            <Layout className="w-4 h-4" /> Preview UI
          </button>
          <button onClick={() => setViewMode('code')} className={\`px-4 py-2 text-xs font-bold rounded-md flex items-center gap-2 \${viewMode === 'code' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}\`}>
            <Code2 className="w-4 h-4" /> Next.js Code
          </button>
        </div>`;
content = content.replace(toggleButtons, '');

// Remove {viewMode === 'preview' ? (
content = content.replace(/\{viewMode === 'preview' \? \(\s*<div className="max-w-6xl mx-auto space-y-8">/, '<div className="max-w-6xl mx-auto space-y-8">');

// Remove the else block and closing brace
const elseCodeBlock = `        ) : (
          <div className="max-w-4xl mx-auto relative group">
            <div className="mb-4">
              <h3 className="text-lg font-bold text-slate-800">app/reports/page.tsx</h3>
              <p className="text-xs text-slate-500">Salin kode ini ke dalam proyek Next.js Anda (App Router).</p>
            </div>
            <pre className="bg-slate-50 border border-slate-200 text-slate-800 p-6 pt-16 rounded-2xl overflow-x-auto text-xs font-mono shadow-inner">
              <code>{nextJsCode}</code>
            </pre>
          </div>
        )}`;

content = content.replace(elseCodeBlock, '');

fs.writeFileSync('src/components/ReportsView.tsx', content);
console.log('Fixed ReportsView.tsx safely');
