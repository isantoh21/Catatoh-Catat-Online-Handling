const fs = require('fs');

function extractAndReplace(filename, componentName) {
  let content = fs.readFileSync(filename, 'utf8');
  
  // Regex to extract the content inside nextJsCode = `...`
  const match = content.match(/const nextJsCode = \`((?:.|\n)*?)\`;\n\nexport default function/);
  
  if (match && match[1]) {
    let nextCode = match[1];
    
    // Remove 'use client';
    nextCode = nextCode.replace(/'use client';\n/g, '');
    
    // Rename component
    nextCode = nextCode.replace(/export default function \w+\(\)/, `export default function ${componentName}()`);
    
    // Write back
    fs.writeFileSync(filename, nextCode);
    console.log("Updated", filename);
  } else {
    console.log("Could not find nextJsCode in", filename);
  }
}

extractAndReplace('src/components/DashboardView.tsx', 'DashboardView');
extractAndReplace('src/components/StudentsView.tsx', 'StudentsView');
extractAndReplace('src/components/ReportsView.tsx', 'ReportsView');
