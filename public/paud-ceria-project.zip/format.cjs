const fs = require('fs');
const prettier = require('prettier');

async function formatFile() {
  const code = fs.readFileSync('src/components/DashboardView.tsx', 'utf8');
  try {
    const formatted = await prettier.format(code, { parser: 'typescript', filepath: 'src/components/DashboardView.tsx' });
    fs.writeFileSync('src/components/DashboardView.tsx', formatted);
    console.log('Formatted successfully');
  } catch (e) {
    console.error('Format failed:', e.message);
  }
}
formatFile();
