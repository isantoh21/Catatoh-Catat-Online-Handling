const fs = require('fs');
let lines = fs.readFileSync('src/components/DashboardView.tsx', 'utf8').split('\n');

// Find the line with {/* Payment Modal */}
const idx = lines.findIndex(l => l.includes('{/* Payment Modal */}'));
if (idx !== -1) {
  // Insert )} right before it
  lines.splice(idx, 0, '      )}');
  fs.writeFileSync('src/components/DashboardView.tsx', lines.join('\n'));
  console.log('Inserted )} at line', idx);
}
