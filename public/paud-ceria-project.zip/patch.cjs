const fs = require('fs');
let code = fs.readFileSync('src/components/DashboardView.tsx', 'utf-8');

code = code.replace(
  /const handleBatalkanLunas = async \(paymentId: string\) => {[\s\S]*?setIsSubmitting\(false\);\n  };/m,
  `const handleBatalkanLunas = async (studentId: string, explicitBulan?: string) => {
    if (!window.confirm('Yakin ingin membatalkan status lunas ini?')) return;
    setIsSubmitting(true);
    const { error } = await supabase
      .from('payments')
      .delete()
      .eq('student_id', studentId)
      .eq('bulan', explicitBulan || selectedBulan)
      .eq('tahun', parseInt(selectedTahun));
      
    if (!error) await fetchData();
    else alert('Gagal membatalkan lunas: ' + error.message);
    setIsSubmitting(false);
  };`
);

// We have two places where handleBatalkanLunas is called.
// One is in the Matrix view (where 'b' is in scope):
// onClick={() => handleBatalkanLunas(payment.id)} -> onClick={() => handleBatalkanLunas(student.id, b)}
// We need to be careful with regex replacement to distinct them.

fs.writeFileSync('src/components/DashboardView.tsx', code);
