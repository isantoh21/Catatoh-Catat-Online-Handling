const fs = require('fs');
let code = fs.readFileSync('src/components/DashboardView.tsx', 'utf-8');

code = code.replace(
  /const handleBatalkanLunas = async \(paymentId: string\) => {[\s\S]*?};/g,
  `const handleBatalkanLunas = async (studentId: string, explicitBulan?: string) => {
    if (!window.confirm('Yakin ingin membatalkan status lunas ini?')) return;
    setIsSubmitting(true);
    const { error } = await supabase
      .from('payments')
      .delete()
      .eq('student_id', studentId)
      .eq('bulan', explicitBulan || selectedBulan)
      .eq('tahun', parseInt(selectedTahun));
      
    if (!error) await fetchData();
    else alert('Gagal membatalkan lunas: ' + error.message);
    setIsSubmitting(false);
  };`
);

code = code.replace(
  /onClick=\{\(\) => handleBatalkanLunas\(payment\.id\)\}/g,
  'onClick={() => handleBatalkanLunas(student.id, b || undefined)}'
);

// We need to fix the monthly table button which doesn't have 'b'
code = code.replace(
  /onClick=\{\(\) => handleBatalkanLunas\(student\.id, undefined \|\| undefined\)\}/g,
  'onClick={() => handleBatalkanLunas(student.id)}'
);

fs.writeFileSync('src/components/DashboardView.tsx', code);
