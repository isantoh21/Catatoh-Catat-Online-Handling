const fs = require('fs');
let code = fs.readFileSync('src/components/StudentsView.tsx', 'utf-8');

code = code.replace(
  /const handleDelete = async \(id: string\) => {[\s\S]*?};/m,
  `const handleDelete = async (id: string) => {
    if (!window.confirm('Yakin ingin menghapus data siswa ini?')) return;
    setLoading(true);
    await supabase.from('payments').delete().eq('student_id', id);
    const { error } = await supabase.from('students').delete().eq('id', id);
    if (error) alert('Gagal menghapus: ' + error.message);
    else fetchStudents();
    setLoading(false);
  };`
);

code = code.replace(
  /const handleBulkDelete = async \(\) => {[\s\S]*?};/m,
  `const handleBulkDelete = async () => {
    if (selectedIds.length === 0) return;
    if (!window.confirm(\`Yakin ingin menghapus \${selectedIds.length} data siswa terpilih?\`)) return;
    
    setLoading(true);
    await supabase.from('payments').delete().in('student_id', selectedIds);
    const { error } = await supabase.from('students').delete().in('id', selectedIds);
    if (error) {
      alert('Gagal menghapus: ' + error.message);
    } else {
      setSelectedIds([]);
      fetchStudents();
    }
    setLoading(false);
  };`
);

fs.writeFileSync('src/components/StudentsView.tsx', code);
