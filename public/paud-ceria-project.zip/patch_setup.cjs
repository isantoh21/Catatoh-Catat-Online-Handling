const fs = require('fs');

let setupGuide = fs.readFileSync('src/components/SetupGuide.tsx', 'utf8');

setupGuide = setupGuide.replace(
  /CREATE TABLE payments \(/,
  `CREATE TABLE expenses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nama_pengeluaran TEXT NOT NULL,
  nominal NUMERIC NOT NULL,
  tanggal DATE NOT NULL,
  bulan TEXT NOT NULL,
  tahun INT NOT NULL
);

CREATE TABLE payments (`
);

setupGuide = setupGuide.replace(
  /ALTER TABLE payments ENABLE ROW LEVEL SECURITY;/,
  `ALTER TABLE payments ENABLE ROW LEVEL SECURITY;\nALTER TABLE expenses ENABLE ROW LEVEL SECURITY;`
);

setupGuide = setupGuide.replace(
  /alter publication supabase_realtime add table payments;/,
  `alter publication supabase_realtime add table payments;\nalter publication supabase_realtime add table expenses;`
);

setupGuide = setupGuide.replace(
  /CREATE POLICY "Allow ALL on payments for authenticated users" \nON payments FOR ALL \nTO authenticated \nUSING \(true\) \nWITH CHECK \(true\);/,
  `CREATE POLICY "Allow ALL on payments for authenticated users" 
ON payments FOR ALL 
TO authenticated 
USING (true) 
WITH CHECK (true);

CREATE POLICY "Allow ALL on expenses for authenticated users" 
ON expenses FOR ALL 
TO authenticated 
USING (true) 
WITH CHECK (true);`
);

fs.writeFileSync('src/components/SetupGuide.tsx', setupGuide);
