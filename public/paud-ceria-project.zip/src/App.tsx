import React, { useState, useEffect } from 'react';
import { supabase } from './lib/supabaseClient';
import SetupGuide from './components/SetupGuide';
import StudentsView from './components/StudentsView';
import DashboardView from './components/DashboardView';
import ReportsView from './components/ReportsView';
import LoginView from './components/LoginView';
import { BookOpen, Users, LayoutDashboard, FileText, MessageCircle, Settings, LogOut, Database, Wifi, WifiOff } from 'lucide-react';
import SettingsView from './components/SettingsView';

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'students' | 'reports' | 'settings'>('dashboard');
  const [dbStatus, setDbStatus] = useState<'checking' | 'connected' | 'error'>('checking');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  const [schoolName, setSchoolName] = useState('PAUD Ceria');
  const [schoolLogo, setSchoolLogo] = useState('');

  
  useEffect(() => {
    // Check active session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setIsLoggedIn(!!session);
      setIsInitializing(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setIsLoggedIn(!!session);
    });

    const savedName = localStorage.getItem('schoolName');
    if (savedName) setSchoolName(savedName);
    const savedLogo = localStorage.getItem('schoolLogo');
    if (savedLogo) setSchoolLogo(savedLogo);

    const checkDb = async () => {
      const url = 'https://lzvrhtaewonmpsaiezai.supabase.co';
      if (!url || url.includes('placeholder')) {
        setDbStatus('error');
        return;
      }
      try {
        const { error } = await supabase.from('students').select('id', { count: 'exact', head: true });
        if (error && error.message && error.message.includes('Failed to fetch')) {
          setDbStatus('error');
        } else {
          setDbStatus('connected');
        }
      } catch (err) {
        setDbStatus('error');
      }
    };
    checkDb();

    return () => subscription.unsubscribe();
  }, []);

  const handleLogin = () => {
    setIsLoggedIn(true);
    setActiveTab('dashboard');
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setIsLoggedIn(false);
    setActiveTab('dashboard');
  };


  return (
    <div className="flex h-screen w-screen bg-slate-50 font-sans overflow-hidden text-slate-800">
      {isInitializing ? (
        <div className="flex-1 flex items-center justify-center bg-slate-50">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
        </div>
      ) : !isLoggedIn ? (
        <LoginView onLogin={handleLogin} schoolName={schoolName} schoolLogo={schoolLogo} />
      ) : (
      <>
      <aside className="w-64 bg-indigo-900 text-indigo-100 flex flex-col hidden md:flex shrink-0">
        <div className="p-6 flex items-center gap-3 border-b border-indigo-800">
          {schoolLogo ? (
            <div className="w-10 h-10 rounded-lg overflow-hidden shrink-0 bg-white">
              <img src={schoolLogo} alt="Logo" className="w-full h-full object-cover" />
            </div>
          ) : (
            <div className="w-10 h-10 bg-amber-400 rounded-lg flex items-center justify-center text-indigo-900 font-bold text-xl shrink-0">
              {schoolName ? schoolName.charAt(0).toUpperCase() : 'P'}
            </div>
          )}
          <div className="overflow-hidden">
            <h1 className="font-bold text-sm leading-tight text-white truncate" title={schoolName}>{schoolName}</h1>
            <p className="text-[10px] opacity-70 uppercase tracking-wider font-semibold">Admin Panel</p>
          </div>
        </div>
        
        <nav className="flex-1 py-6 px-4 space-y-1">
          <button 
             onClick={() => setActiveTab('dashboard')} 
             className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
              activeTab === 'dashboard' ? 'bg-indigo-800 text-white' : 'hover:bg-indigo-800/50 text-indigo-200'
            }`}
          >
            <LayoutDashboard className="w-5 h-5" />
            Pembayaran SPP
          </button>
          
          <button 
             onClick={() => setActiveTab('students')} 
             className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
              activeTab === 'students' ? 'bg-indigo-800 text-white' : 'hover:bg-indigo-800/50 text-indigo-200'
            }`}
          >
            <Users className="w-5 h-5" />
            Data Siswa
          </button>

          <button 
             onClick={() => setActiveTab('reports')} 
             className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${
              activeTab === 'reports' ? 'bg-indigo-800 text-white' : 'hover:bg-indigo-800/50 text-indigo-200'
            }`}
          >
            <FileText className="w-5 h-5" />
            Laporan Bulanan
          </button>

          <div className="pt-4 mt-4 border-t border-indigo-800/50">
            <button 
               onClick={() => setActiveTab('settings')} 
               className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-colors ${
                activeTab === 'settings' ? 'bg-amber-400 text-indigo-900 shadow-md' : 'bg-indigo-800/50 text-indigo-100 hover:bg-amber-400/90 hover:text-indigo-900'
              }`}
            >
              <Settings className="w-5 h-5" />
              Pengaturan Profil
            </button>
          </div>
        </nav>
        
        <div className="p-6 mt-auto">
          <button 
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-3 px-4 py-3 rounded-xl text-sm font-bold text-rose-300 hover:bg-rose-900/30 transition-colors mb-4 border border-rose-900/30 hover:border-rose-900/50"
          >
            <LogOut className="w-4 h-4" /> Keluar Aplikasi
          </button>
          <div className="bg-indigo-800 rounded-2xl p-4 text-center">
            <p className="text-[11px] font-semibold text-indigo-300 uppercase tracking-widest mb-1">Bantuan</p>
            <p className="text-xs text-white mb-3">Butuh bantuan input?</p>
            <button className="w-full py-2 bg-indigo-700 hover:bg-indigo-600 text-white transition-colors rounded-lg text-xs font-bold flex items-center justify-center gap-2">
              <MessageCircle className="w-4 h-4" /> WhatsApp
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile nav indicator */}
      <div className="md:hidden flex bg-indigo-900 text-white border-b border-indigo-800 shrink-0 overflow-x-auto">
        <button 
           onClick={() => setActiveTab('dashboard')} 
           className={`px-4 py-4 text-xs font-bold whitespace-nowrap text-center border-b-2 ${activeTab === 'dashboard' ? 'border-amber-400 text-amber-400' : 'border-transparent text-indigo-300'}`}
        >
          SPP
        </button>
        <button 
           onClick={() => setActiveTab('students')} 
           className={`px-4 py-4 text-xs font-bold whitespace-nowrap text-center border-b-2 ${activeTab === 'students' ? 'border-amber-400 text-amber-400' : 'border-transparent text-indigo-300'}`}
        >
          Siswa
        </button>
        <button 
           onClick={() => setActiveTab('reports')} 
           className={`px-4 py-4 text-xs font-bold whitespace-nowrap text-center border-b-2 ${activeTab === 'reports' ? 'border-amber-400 text-amber-400' : 'border-transparent text-indigo-300'}`}
        >
          Laporan
        </button>
        <button 
           onClick={() => setActiveTab('settings')} 
           className={`px-4 py-4 text-xs font-bold whitespace-nowrap text-center border-b-2 ${activeTab === 'settings' ? 'border-amber-400 text-amber-400' : 'border-transparent text-indigo-300'}`}
        >
          Pengaturan
        </button>
      </div>

      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* DB Connection Status Bar */}
        <div className={`px-4 py-2 text-xs font-bold flex items-center justify-between shrink-0 ${dbStatus === 'connected' ? 'bg-emerald-500 text-white' : dbStatus === 'checking' ? 'bg-slate-200 text-slate-500' : 'bg-rose-500 text-white'}`}>
          <div className="flex items-center gap-2">
            {dbStatus === 'connected' ? <Wifi className="w-4 h-4" /> : dbStatus === 'checking' ? <Database className="w-4 h-4 animate-pulse" /> : <WifiOff className="w-4 h-4" />}
            <span>
              {dbStatus === 'connected' ? 'Terhubung ke Database (Supabase)' : dbStatus === 'checking' ? 'Mengecek Koneksi Database...' : 'Tidak Terhubung ke Database (Cek koneksi internet atau .env.local)'}
            </span>
          </div>
          {dbStatus === 'error' && (
            <span className="text-[10px] bg-black/20 px-2 py-1 rounded-md uppercase tracking-wider">Offline</span>
          )}
        </div>
        {activeTab === 'dashboard' ? <DashboardView /> : activeTab === 'reports' ? <ReportsView /> : activeTab === 'settings' ? <SettingsView schoolName={schoolName} setSchoolName={setSchoolName} schoolLogo={schoolLogo} setSchoolLogo={setSchoolLogo} /> : <StudentsView />}
      </main>
      </>
      )}
    </div>
  );
}
