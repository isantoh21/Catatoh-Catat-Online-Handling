import React, { useState } from 'react';
import { Mail, Lock, LogIn } from 'lucide-react';
import { supabase } from '../lib/supabaseClient';

export default function LoginView({ 
    onLogin, 
    schoolName = 'PAUD Ceria', 
    schoolLogo = '' 
  }: { 
    onLogin?: () => void; 
    schoolName?: string; 
    schoolLogo?: string; 
  }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        setError(error.message || 'Login gagal.');
      } else if (data.session) {
        if (onLogin) onLogin();
      }
    } catch (err: any) {
      setError(err.message || 'Terjadi kesalahan jaringan.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-slate-50 font-sans items-center justify-center">
      <div className="w-full max-w-md mx-auto rounded-2xl shadow-xl border border-slate-200 overflow-hidden bg-white">
        <div className="bg-indigo-900 p-8 text-center">
          {schoolLogo ? (
            <div className="w-16 h-16 rounded-2xl mx-auto flex items-center justify-center mb-4 shadow-sm overflow-hidden bg-white">
              <img src={schoolLogo} alt="Logo" className="w-full h-full object-cover" />
            </div>
          ) : (
            <div className="w-16 h-16 bg-amber-400 rounded-2xl mx-auto flex items-center justify-center text-indigo-900 font-bold text-3xl mb-4 shadow-sm">
              {schoolName ? schoolName.charAt(0).toUpperCase() : 'P'}
            </div>
          )}
          <h1 className="text-2xl font-bold text-white">{schoolName}</h1>
          <p className="text-indigo-200 text-sm mt-1">Sistem Manajemen SPP</p>
        </div>
        
        <form onSubmit={handleLogin} className="p-8 space-y-6">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-100 text-rose-700 rounded-lg text-sm font-medium">
              {error}
            </div>
          )}
          
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Email Admin</label>
            <div className="relative">
              <Mail className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="email" 
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="admin@paudceria.com" 
                className="w-full pl-10 pr-4 py-3 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm bg-white text-slate-800"
              />
            </div>
          </div>
          
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Password</label>
            <div className="relative">
              <Lock className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="password" 
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••" 
                className="w-full pl-10 pr-4 py-3 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm bg-white text-slate-800"
              />
            </div>
          </div>

          <button 
            type="submit" 
            disabled={loading}
            className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold flex items-center justify-center gap-2 transition-colors shadow-md disabled:opacity-70"
          >
            {loading ? 'Memverifikasi...' : (
              <>
                <LogIn className="w-5 h-5" /> Masuk ke Dashboard
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
