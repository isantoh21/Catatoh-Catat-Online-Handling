import React, { useState, useRef, useEffect } from 'react';
import { Camera, Save, Building2, UploadCloud, CheckCircle2 } from 'lucide-react';

export default function SettingsView({ 
  schoolName, 
  setSchoolName, 
  schoolLogo, 
  setSchoolLogo 
}: { 
  schoolName: string; 
  setSchoolName: (v: string) => void;
  schoolLogo: string;
  setSchoolLogo: (v: string) => void;
}) {
  const [localName, setLocalName] = useState(schoolName);
  const [localLogo, setLocalLogo] = useState(schoolLogo);
  const [isSaved, setIsSaved] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setLocalName(schoolName);
    setLocalLogo(schoolLogo);
  }, [schoolName, schoolLogo]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLocalLogo(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    setSchoolName(localName);
    setSchoolLogo(localLogo);
    localStorage.setItem('schoolName', localName);
    localStorage.setItem('schoolLogo', localLogo);
    
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-slate-50 font-sans">
      <div className="p-6 md:px-10 md:py-8 border-b border-slate-200 bg-white">
        <h2 className="text-xl font-bold text-slate-800">Pengaturan Profil Sekolah</h2>
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mt-1">Sesuaikan identitas PAUD Anda</p>
      </div>

      <div className="flex-1 overflow-auto p-6 md:p-10">
        <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-8 space-y-8">
            
            {/* Logo Section */}
            <div>
              <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2">
                <Camera className="w-4 h-4 text-indigo-500" /> Logo / Profile Picture
              </h3>
              
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
                <div className="w-24 h-24 rounded-2xl bg-indigo-50 border-2 border-dashed border-indigo-200 flex items-center justify-center overflow-hidden shrink-0 relative group">
                  {localLogo ? (
                    <img src={localLogo} alt="School Logo" className="w-full h-full object-cover" />
                  ) : (
                    <div className="text-indigo-300 font-bold text-3xl">
                      {localName ? localName.charAt(0).toUpperCase() : 'P'}
                    </div>
                  )}
                  
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"
                  >
                    <UploadCloud className="w-6 h-6 text-white" />
                  </button>
                </div>
                
                <div className="space-y-2">
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={handleFileChange} 
                    accept="image/*" 
                    className="hidden" 
                  />
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="px-4 py-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg text-sm font-bold transition-colors shadow-sm"
                  >
                    Pilih Gambar
                  </button>
                  <p className="text-xs text-slate-500">Format: JPG, PNG, GIF. Maksimal 2MB.</p>
                  {localLogo && (
                    <button 
                      onClick={() => setLocalLogo('')}
                      className="text-xs text-rose-500 font-semibold hover:text-rose-600 transition-colors"
                    >
                      Hapus Logo
                    </button>
                  )}
                </div>
              </div>
            </div>

            <hr className="border-slate-100" />

            {/* Nama Sekolah Section */}
            <div>
              <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-indigo-500" /> Nama Sekolah (PAUD)
              </h3>
              
              <div className="max-w-md">
                <input 
                  type="text" 
                  value={localName}
                  onChange={e => setLocalName(e.target.value)}
                  placeholder="Contoh: PAUD Ceria, TK Harapan Bangsa" 
                  className="w-full px-4 py-3 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm font-medium text-slate-800"
                />
              </div>
            </div>

            {/* Save Button */}
            <div className="pt-4 flex items-center gap-4">
              <button 
                onClick={handleSave}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-bold transition-colors shadow-sm flex items-center gap-2"
              >
                <Save className="w-4 h-4" /> Simpan Perubahan
              </button>
              
              {isSaved && (
                <span className="flex items-center gap-1.5 text-sm font-bold text-emerald-600 animate-in fade-in duration-300">
                  <CheckCircle2 className="w-4 h-4" /> Tersimpan!
                </span>
              )}
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
