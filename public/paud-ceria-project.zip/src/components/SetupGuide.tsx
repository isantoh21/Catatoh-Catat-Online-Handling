import React, { useState } from 'react';
import { Database, Code2, Terminal, CheckCircle2, Copy } from 'lucide-react';

export default function SetupGuide() {
  const [copied, setCopied] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const sqlSchema = `-- Aktifkan ekstensi uuid jika belum ada
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabel students
CREATE TABLE students (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL DEFAULT auth.uid(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  nama_lengkap TEXT NOT NULL,
  nomor_whatsapp TEXT NOT NULL CHECK (nomor_whatsapp LIKE '62%'),
  nominal_spp NUMERIC NOT NULL DEFAULT 100000,
  status_aktif BOOLEAN DEFAULT true
);

-- Tabel payments
CREATE TABLE expenses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL DEFAULT auth.uid(),
  nama_pengeluaran TEXT NOT NULL,
  nominal NUMERIC NOT NULL,
  tanggal DATE NOT NULL,
  bulan TEXT NOT NULL,
  tahun INT NOT NULL
);

CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL DEFAULT auth.uid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  bulan TEXT NOT NULL,
  tahun INT NOT NULL,
  nominal_dibayar NUMERIC NOT NULL,
  tanggal_bayar DATE NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('Lunas', 'Belum'))
);

-- Setup Row Level Security (RLS)
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;

-- RLS Policies - HANYA untuk authenticated user (User yang sudah login via Supabase Auth)
CREATE POLICY "Isolasi data students" ON students FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Aktifkan Realtime untuk sinkronisasi terus menerus
alter publication supabase_realtime add table students;
alter publication supabase_realtime add table payments;
alter publication supabase_realtime add table expenses;

CREATE POLICY "Isolasi data payments" ON payments FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Isolasi data expenses" ON expenses FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);`;

  const supabaseClientCode = `import { createClient } from '@supabase/supabase-js';

// URL dan Anon Key didapatkan dari dashboard Supabase
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

// NOTE: Untuk client component (browser), disarankan menggunakan 
// createBrowserClient dari @supabase/ssr. Namun ini adalah client default:
export const supabase = createClient(supabaseUrl, supabaseAnonKey);`;

  const middlewareCode = `import { createServerClient } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';

export async function middleware(request: NextRequest) {
  let supabaseResponse = NextResponse.next({
    request,
  });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
          supabaseResponse = NextResponse.next({
            request,
          });
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          );
        },
      },
    }
  );

  // Ambil sesi user saat ini
  const { data: { user } } = await supabase.auth.getUser();

  const isAuthRoute = request.nextUrl.pathname.startsWith('/login');
  
  // Jika belum login dan mencoba akses route internal (selain /login), redirect ke /login
  if (!user && !isAuthRoute && request.nextUrl.pathname !== '/') {
    const url = request.nextUrl.clone();
    url.pathname = '/login';
    return NextResponse.redirect(url);
  }

  // Jika sudah login tapi mencoba akses /login, redirect ke /dashboard
  if (user && isAuthRoute) {
    const url = request.nextUrl.clone();
    url.pathname = '/dashboard';
    return NextResponse.redirect(url);
  }

  return supabaseResponse;
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\\\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)'],
};`;

  const envCode = `NEXT_PUBLIC_SUPABASE_URL=https://<project-id>.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`;

  const nextJsUsageCode = `import { supabase } from '@/lib/supabaseClient';

// Contoh Server Component di Next.js (App Router)
export default async function Page() {
  const { data: students } = await supabase.from('students').select('*');

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Daftar Siswa PAUD</h1>
      <ul className="space-y-2">
        {students?.map(student => (
          <li key={student.id} className="p-3 border rounded">
            {student.nama_lengkap} - {student.nomor_whatsapp}
          </li>
        ))}
      </ul>
    </div>
  );
}`;

  return (
    <div className="flex-1 overflow-auto bg-slate-50 text-slate-800 p-6 md:p-10 font-sans">
      <div className="max-w-4xl w-full mx-auto space-y-6 pb-12">
        
        {/* Header */}
        <div className="bg-indigo-900 p-8 rounded-2xl shadow-sm border border-indigo-800 text-indigo-100">
          <div className="flex items-center gap-4 mb-4">
             <div className="w-12 h-12 bg-amber-400 rounded-xl flex items-center justify-center text-indigo-900 font-bold text-2xl">P</div>
             <div>
               <h1 className="text-2xl font-bold text-white mb-1">Setup Aplikasi SPP PAUD</h1>
               <p className="text-indigo-300 uppercase tracking-widest text-[10px] font-semibold">Panduan Integrasi</p>
             </div>
          </div>
          <p className="text-indigo-200 text-sm">
            Panduan lengkap integrasi Next.js (App Router), Tailwind CSS, dan Supabase sesuai permintaan Anda.
          </p>
        </div>

        {/* 1. SQL Schema */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg">
              <Database className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-slate-700">1. Skema SQL (Supabase)</h2>
          </div>
          <p className="text-slate-500 mb-4 text-xs">
            Jalankan skema ini di menu <strong>SQL Editor</strong> pada dashboard Supabase Anda.
          </p>
          <div className="relative group">
            <button
              onClick={() => copyToClipboard(sqlSchema, 'sql')}
              className="absolute right-4 top-4 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors text-xs font-bold flex items-center gap-2"
            >
              {copied === 'sql' ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
            <pre className="bg-slate-50 border border-slate-100 text-slate-800 p-6 rounded-xl overflow-x-auto text-xs font-mono shadow-inner">
              <code>{sqlSchema}</code>
            </pre>
          </div>
        </div>

        {/* 2. Supabase Connection */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg">
              <Terminal className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-slate-700">2. Koneksi Next.js & Supabase</h2>
          </div>
          
          <div className="space-y-6">
            {/* Step A */}
            <div>
              <h3 className="font-bold text-slate-800 mb-2 text-sm flex items-center gap-2">
                <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
                A. Instalasi Dependency
              </h3>
              <p className="text-xs text-slate-500 mb-2">Jalankan perintah ini di terminal proyek Next.js Anda (termasuk SSR untuk middleware):</p>
              <div className="bg-slate-50 border border-slate-100 text-indigo-600 p-4 rounded-xl font-mono text-xs font-bold shadow-inner">
                npm install @supabase/supabase-js @supabase/ssr
              </div>
            </div>

            {/* Step B */}
            <div>
              <h3 className="font-bold text-slate-800 mb-2 text-sm flex items-center gap-2">
                <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
                B. Environment Variables (.env.local)
              </h3>
              <p className="text-xs text-slate-500 mb-2">Buat file <code>.env.local</code> di root folder dan isi dengan URL dan Anon Key dari Project Settings Supabase.</p>
              <div className="relative group">
                <button
                  onClick={() => copyToClipboard(envCode, 'env')}
                  className="absolute right-4 top-4 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors text-xs font-bold flex items-center gap-2"
                >
                  {copied === 'env' ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </button>
                <pre className="bg-slate-50 border border-slate-100 text-slate-800 p-6 rounded-xl overflow-x-auto text-xs font-mono shadow-inner">
                  <code>{envCode}</code>
                </pre>
              </div>
            </div>

            {/* Step C */}
            <div>
              <h3 className="font-bold text-slate-800 mb-2 text-sm flex items-center gap-2">
                <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
                C. Buat File lib/supabaseClient.ts
              </h3>
              <p className="text-xs text-slate-500 mb-2">Buat file baru di <code>lib/supabaseClient.ts</code> (atau <code>src/lib/supabaseClient.ts</code>) dan paste kode berikut:</p>
              <div className="relative group">
                <button
                  onClick={() => copyToClipboard(supabaseClientCode, 'client')}
                  className="absolute right-4 top-4 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors text-xs font-bold flex items-center gap-2"
                >
                  {copied === 'client' ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </button>
                <pre className="bg-slate-50 border border-slate-100 text-slate-800 p-6 rounded-xl overflow-x-auto text-xs font-mono shadow-inner">
                  <code>{supabaseClientCode}</code>
                </pre>
              </div>
            </div>

            {/* Step D */}
            <div>
              <h3 className="font-bold text-slate-800 mb-2 text-sm flex items-center gap-2">
                <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
                D. Buat File Middleware (middleware.ts)
              </h3>
              <p className="text-xs text-slate-500 mb-2">Buat file <code>middleware.ts</code> di root proyek Anda untuk memproteksi rute dari user yang belum login:</p>
              <div className="relative group">
                <button
                  onClick={() => copyToClipboard(middlewareCode, 'middleware')}
                  className="absolute right-4 top-4 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors text-xs font-bold flex items-center gap-2"
                >
                  {copied === 'middleware' ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </button>
                <pre className="bg-slate-50 border border-slate-100 text-slate-800 p-6 rounded-xl overflow-x-auto text-xs font-mono shadow-inner">
                  <code>{middlewareCode}</code>
                </pre>
              </div>
            </div>
          </div>
        </div>

        {/* 3. Usage Example */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-amber-100 text-amber-600 rounded-lg">
              <Code2 className="w-5 h-5" />
            </div>
            <h2 className="text-lg font-bold text-slate-700">3. Contoh Penggunaan (App Router)</h2>
          </div>
          <p className="text-slate-500 mb-4 text-xs">
            Anda dapat memanggil Supabase client langsung di dalam Server Component untuk melakukan fetch data <i>students</i> atau <i>payments</i> secara aman di server.
          </p>
          <div className="relative group">
            <button
              onClick={() => copyToClipboard(nextJsUsageCode, 'usage')}
              className="absolute right-4 top-4 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors text-xs font-bold flex items-center gap-2"
            >
              {copied === 'usage' ? <CheckCircle2 className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
            <pre className="bg-slate-50 border border-slate-100 text-slate-800 p-6 rounded-xl overflow-x-auto text-xs font-mono shadow-inner">
              <code>{nextJsUsageCode}</code>
            </pre>
          </div>
        </div>
        
        {/* Footer info */}
        <div className="text-center text-xs font-medium text-slate-400 mt-6 pb-6 uppercase tracking-widest">
          File <code className="bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded font-mono lowercase tracking-normal">src/lib/supabaseClient.ts</code> dan <code className="bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded font-mono lowercase tracking-normal">supabase_schema.sql</code> juga telah dibuat di workspace proyek ini.
        </div>
      </div>
    </div>
  );
}
