-- Aktifkan ekstensi uuid jika belum ada
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabel students
CREATE TABLE students (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  nama_lengkap TEXT NOT NULL,
  nomor_whatsapp TEXT NOT NULL CHECK (nomor_whatsapp LIKE '62%'),
  nominal_spp NUMERIC NOT NULL DEFAULT 100000,
  status_aktif BOOLEAN DEFAULT true
);

-- Tabel payments
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  bulan TEXT NOT NULL,
  tahun INT NOT NULL,
  nominal_dibayar NUMERIC NOT NULL,
  tanggal_bayar DATE NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('Lunas', 'Belum'))
);

-- Setup Row Level Security (RLS)
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- RLS Policies - HANYA untuk authenticated user (User yang sudah login via Supabase Auth)
CREATE POLICY "Allow ALL on students for authenticated users" 
ON students FOR ALL 
TO authenticated 
USING (true) 
WITH CHECK (true);

CREATE POLICY "Allow ALL on payments for authenticated users" 
ON payments FOR ALL 
TO authenticated 
USING (true) 
WITH CHECK (true);
