const { createClient } = require('@supabase/supabase-js');
const supabase = createClient('https://lzvrhtaewonmpsaiezai.supabase.co', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imx6dnJodGFld29ubXBzYWllemFpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODc4MDE5NDQsImV4cCI6MjEwMzM3Nzk0NH0.UfWotWAZQjaqTTjoa5GKS5dq1Zda3V6wQlaCpHRNGI8');
async function test() {
  const { data: { session }, error: authError } = await supabase.auth.signInWithPassword({
    email: 'isantoh21@gmail.com', // Let's see if we can get a session if they use a dummy pass? No.
    password: 'wrong' // Actually we can't test without their pass
  });
}
