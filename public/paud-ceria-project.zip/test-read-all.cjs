const { createClient } = require('@supabase/supabase-js');
const supabase = createClient('https://lzvrhtaewonmpsaiezai.supabase.co', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imx6dnJodGFld29ubXBzYWllemFpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODc4MDE5NDQsImV4cCI6MjEwMzM3Nzk0NH0.UfWotWAZQjaqTTjoa5GKS5dq1Zda3V6wQlaCpHRNGI8');
async function test() {
  const { data: students, error: err1 } = await supabase.from('students').select('*');
  console.log("Students:", students?.length, err1);
  const { data: payments, error: err2 } = await supabase.from('payments').select('*');
  console.log("Payments:", payments?.length, err2);
}
test();
