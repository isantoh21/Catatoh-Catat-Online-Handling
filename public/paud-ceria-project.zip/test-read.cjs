const { createClient } = require('@supabase/supabase-js');
const supabase = createClient('https://lzvrhtaewonmpsaiezai.supabase.co', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imx6dnJodGFld29ubXBzYWllemFpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODc4MDE5NDQsImV4cCI6MjEwMzM3Nzk0NH0.UfWotWAZQjaqTTjoa5GKS5dq1Zda3V6wQlaCpHRNGI8');
async function test() {
  const { data, error } = await supabase.from('students').select('*');
  console.log("Students read:", data ? data.length : 0, error);
  const { data: pData, error: pError } = await supabase.from('payments').select('*');
  console.log("Payments read:", pData ? pData.length : 0, pError);
}
test();
