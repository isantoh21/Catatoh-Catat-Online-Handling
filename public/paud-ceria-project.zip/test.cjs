const fs = require('fs');
const code = fs.readFileSync('src/components/DashboardView.tsx', 'utf8');

const lines = code.split('\n');
lines.forEach((line, i) => {
  if (line.includes('student.') && !line.includes('student =>') && !line.includes('student:')) {
    console.log(`${i+1}: ${line.trim()}`);
  }
});
