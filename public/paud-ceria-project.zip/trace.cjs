const fs = require('fs');
const code = fs.readFileSync('src/components/DashboardView.tsx', 'utf8');
const lines = code.split('\n');

let depth = 0;
for (let i = 188; i <= 415; i++) {
  const line = lines[i] || "";
  const opens = (line.match(/<[a-zA-Z]/g) || []).length;
  const closes = (line.match(/<\/[a-zA-Z]/g) || []).length;
  const selfClosing = (line.match(/<[a-zA-Z][^>]*\/>/g) || []).length;
  
  // selfClosing are already counted in opens, so we subtract them from opens
  const realOpens = opens - selfClosing;
  
  depth += realOpens - closes;
  
  if (depth === 0 && realOpens > 0) {
    console.log('Depth reached 0 at line', i+1);
  }
}
console.log('Final depth at 415:', depth);
