const AdmZip = require('adm-zip');
const zip = new AdmZip();
const fs = require('fs');

const exclude = ['node_modules', 'dist', 'dist_electron', '.git', 'public', 'bun.lock'];

function addFolderToZip(folder, zipFolder) {
  const files = fs.readdirSync(folder);
  for (const file of files) {
    if (exclude.includes(file)) continue;
    const path = folder + '/' + file;
    if (fs.statSync(path).isDirectory()) {
      addFolderToZip(path, zipFolder + file + '/');
    } else {
      zip.addLocalFile(path, zipFolder);
    }
  }
}

addFolderToZip('.', '');
zip.writeZip('public/paud-ceria-project.zip');
